import os
import requests
import logging
import argparse
from datetime import timezone, datetime
import json


class DicFilesFetcher:

    logger = logging.getLogger("DicFilesFetcher")
    timestamp_file = "last_execution_time.json"

    def __init__(self, download_dir, nautobot_url="http://127.0.0.1:8000"):
        print(download_dir)
        print(nautobot_url)
        self.download_dir = download_dir
        self.last_run_time_file = os.path.join(download_dir, "last_run_time.txt")
        self.nautobot_url = nautobot_url

        try:
            stream_handler = logging.StreamHandler()
            file_handler = logging.FileHandler(
                os.path.join(self.download_dir, "dic_fetcher.log")
            )

            formatter = logging.Formatter(
                "%(asctime)s - %(name)s - %(filename)s:%(lineno)d - %(levelname)s - %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S",
            )
            stream_handler.setFormatter(formatter)
            file_handler.setFormatter(formatter)
            self.logger = logging.getLogger("DicFilesFetcher")
            self.logger.addHandler(stream_handler)
            self.logger.addHandler(file_handler)
            self.logger.setLevel(logging.DEBUG)
        except Exception as e:
            print(f"Error setting up logging: {e}")

    def get_last_execution_time(self):
        try:
            with open(self.timestamp_file, "r") as file:
                data = json.load(file)
                return data["last_execution_time"]
        except (FileNotFoundError, json.JSONDecodeError, KeyError) as e:
            self.logger.error(e)
            return None

    def update_last_execution_time(self):
        current_time = (
            datetime.utcnow().isoformat() + "Z"
        )  # Format as "2024-07-16T12:05:51.762Z"
        with open(self.timestamp_file, "w") as file:
            json.dump({"last_execution_time": current_time}, file)

    def fetch(self):
        self.logger.info("Starting fetch process.")
        # Get the last run time
        if os.path.exists(self.last_run_time_file):
            try:
                last_run_time = self.get_last_execution_time()
                self.logger.info("Last excecution : %s", last_run_time)
            except Exception as e:
                self.logger.error("Error reading last run time: %s", e)
                last_run_time = None
        else:
            last_run_time = None

        # Connect to the Nautobot server and get the list of DIC files
        url = f"{self.nautobot_url}/plugins/es-observability/api/mib-module/generated-dic-files"
        params = {"last_run_time": last_run_time}
        try:
            response = requests.get(url, params=params, verify=False)
            if response.status_code != 200:
                self.logger.error(
                    "Error connecting to the server: %s", response.status_code
                )
                return "Failed"
            data = response.json()
        except Exception as e:
            self.logger.error("Error during server connection: %s", e)
            return "Failed"

        self.logger.info("Response data : %s", data)

        # For each file in the response
        for file in data:
            # Get the path and URL of the file
            path = os.path.join(self.download_dir, file["path"])
            file_url = file["url"]

            # Create the directories in the path if they don't exist
            os.makedirs(os.path.dirname(path), exist_ok=True)
            self.logger.info(file_url)
            try:
                # Send a GET request to the file URL
                file_response = requests.get(file_url, verify=False)

                # If the request was successful
                if file_response.status_code == 200:
                    # Write the file data to the path
                    with open(os.path.join(self.download_dir, path), "wb") as f:
                        f.write(file_response.content)
                    self.logger.info("Successfully downloaded file: %s", path)
                else:
                    self.logger.error(
                        "Failed to download file: %s | Response status code: %s",
                        file_url,
                        file_response.status_code,
                    )
            except Exception as e:
                self.logger.error("Error downloading file: %s | Error: %s", file_url, e)
        try:

            # Store the current time as the last run time
            self.update_last_execution_time()
        except Exception as e:
            self.logger.error("Error writing last run time: %s", e)
            return "Failed"

        self.logger.info("Fetch process completed.")
        return "Success"


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Process some values.")
    parser.add_argument(
        "-d",
        "--dir",
        type=str,
        help="Directory where to download dic files",
    )
    parser.add_argument(
        "-u",
        "--url",
        type=str,
        help="base url of nautobot server, default : http://127.0.0.1:8000 ",
    )
    args = parser.parse_args()

    download_dir = str(args.dir)
    url = args.url
    if url:
        fetcher = DicFilesFetcher(download_dir, str(url))
    else:
        fetcher = DicFilesFetcher(download_dir)
    response = fetcher.fetch()
    print(response)
