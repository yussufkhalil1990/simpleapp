import yaml
import logging
import datetime
from flask import Flask, request, jsonify, render_template_string
from elasticsearch import Elasticsearch



# Configuration du logging
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s -   %(filename)s:%(lineno)d - %(message)s",
)
logger = logging.getLogger(__name__)


class Config:
    def __init__(self, yaml_file):
        with open(yaml_file, "r") as file:
            self.data = yaml.safe_load(file)
        logger.info(f"Configuration loaded from {yaml_file}")

    def get_type_config(self, processor, type):
        if processor == "span":
            config_type = self.data.get("span_types", [])
        elif processor == "transaction":
            config_type = self.data.get("transaction_types", [])
        else:
            logger.error(f"Unknown processor type: {processor}")
            return None

        for t in config_type:
            if t["name"] == type:
                return t
        logger.warning(f"No configuration found for type: {type}")
        return None

    def get_global_config(self):
        logger.info("Loading configurations from YAML file")
        try:
            with open("config.yaml", "r") as file:
                config = yaml.safe_load(file)
            logger.info("Configurations loaded successfully")
            return config
        except Exception as e:
            logger.error(f"Failed to load configurations: {e}")
            raise


class ElasticsearchClient:
    def __init__(self, conf: Config):
        logger.info("Connecting to Elasticsearch")
        config = conf.get_global_config()["elasticsearch"]

        configurations = {
            "basic_auth": (config.get("username"), config.get("password")),
        }
        self.client = Elasticsearch(
            hosts=f"{config.get('scheme')}://{config.get('host')}:{config.get('port')}/",
            **configurations,
            verify_certs=False,
        )

    def execute_query(self, index, query, all=False):
        try:
            # logger.debug(f"Executing query {query} on index {index}")
            response = self.client.search(index=index, body=query)
            hits = response["hits"]["hits"]
            logger.info(f"Query executed successfully on index {index}")
            # data = {hit["_id"]: hit["_source"] for hit in hits}
            if hits:
                data = hits[0]["_source"] if not all else hits
            else:
                data = {}
            logger.info(f"Data retrieved from index {data}")
            return data
        except Exception as e:
            logger.error(f"Error executing query on index {index}: {str(e)}")
            return {}


class QueryBuilder:
    @staticmethod
    def build_direct_query(
        service_name, processor_event, event_name, start_date, end_date, fields
    ):
        attribut = "span.name" if processor_event == "span" else "transaction.name"
        return {
            "query": {
                "bool": {
                    "must": [
                        {"term": {"service.name": service_name}},
                        {"term": {f"{attribut}": event_name}},
                        {"range": {"@timestamp": {"gte": start_date, "lte": end_date}}},
                    ]
                }
            },
            "_source": fields,
        }

    @staticmethod
    def build_indirect_query(association_field, value, start_date, end_date, fields):
        if isinstance(value, list):
            term = "terms"
        else:
            term = "term"
        return {
            "query": {
                "bool": {
                    "must": [
                        {f"{term}": {f"{association_field}": value}},
                        {"range": {"@timestamp": {"gte": start_date, "lte": end_date}}},
                    ]
                }
            },
            "_source": fields,
        }

    @staticmethod
    def build_association_query(
        service_name,
        processor_event,
        event_name,
        start_date,
        end_date,
        association_field,
    ):
        attribut = "span.name" if processor_event == "span" else "transaction.name"
        return {
            "query": {
                "bool": {
                    "must": [
                        {"term": {"service.name": service_name}},
                        {"term": {f"{attribut}": event_name}},
                        {"range": {"@timestamp": {"gte": start_date, "lte": end_date}}},
                    ]
                }
            },
            "_source": association_field,
        }

    @staticmethod
    def get_nested_field(data, field_path, subfields=None):
        keys = field_path.split(".")
        current = data

        for key in keys:
            if isinstance(current, list):
                # If current is a list, accumulate the results from each list item
                result = []
                for item in current:
                    if isinstance(item, dict) and key in item:
                        result.append(item[key])
                    elif isinstance(item, list):  # Handle nested lists
                        result.extend(
                            [
                                sub_item.get(key)
                                for sub_item in item
                                if isinstance(sub_item, dict)
                            ]
                        )
                current = result
            elif isinstance(current, dict):
                current = current.get(key)
                if current is None:
                    return None
            else:
                return None

        # If subfields is specified and 'all' is not in it, filter the result
        if subfields and "all" not in subfields:
            if isinstance(current, dict):
                return {k: v for k, v in current.items() if k in subfields}
            elif isinstance(current, list):
                return [
                    (
                        {k: v for k, v in item.items() if k in subfields}
                        if isinstance(item, dict)
                        else item
                    )
                    for item in current
                ]

        return current


class WebhookHandler:
    def __init__(self, config, es_client):
        self.config = config
        self.es_client = es_client

    def handle(
        self, processor_event, service_name, type, event_name, start_date, end_date
    ):
        logger.info(
            f"Handling webhook request: processor={processor_event}, type={type}, name={event_name}"
        )
        type_config = self.config.get_type_config(processor_event, type)
        if not type_config:
            logger.error(
                f"Configuration not found for processor={processor_event}, type={type}"
            )
            return {"error": "Configuration not found"}, 404

        final_results = []
        logger.debug(f"Type configuration: {type_config['relevant_datastreams']}")
        main_data_stream: str = ""
        for datastream in type_config.get("relevant_datastreams", []):

            if datastream.get("direct_association", False):
                main_data_stream = datastream["name"]
                query = QueryBuilder.build_direct_query(
                    service_name,
                    processor_event,
                    event_name,
                    start_date,
                    end_date,
                    [field["name"] for field in datastream["fields"]],
                )
                response = self.es_client.execute_query(
                    datastream["name"], query, all=True
                )
                results = {}
                final_results = self.process_response_data(response, datastream)

            else:
                logger.info(
                    f"Processing datastream : {main_data_stream} for event: {event_name}  - Indirect association"
                )
                association_query = QueryBuilder.build_association_query(
                    service_name,
                    processor_event,
                    event_name,
                    start_date,
                    end_date,
                    datastream.get("association_fields", []),
                )
                logger.info(f"Association query: {association_query}")

                association_results_data = self.es_client.execute_query(
                    main_data_stream, association_query, all=True
                )
                logger.info(f"Association results: {association_results_data}")
                association_results = {}
                results = {}
                field_data = []
                for data in association_results_data:
                    for field_path in datastream["association_fields"]:
                        association_results[field_path] = QueryBuilder.get_nested_field(
                            data["_source"], field_path
                        )

                    if association_results:
                        query = QueryBuilder.build_indirect_query(
                            field_path,
                            association_results[field_path],
                            start_date,
                            end_date,
                            [field["name"] for field in datastream["fields"]],
                        )
                        logger.info(f" Indirect Query: {query}")
                        response = self.es_client.execute_query(
                            datastream["name"], query, all=True
                        )
                        field_data.extend(
                            self.process_response_data(response, datastream)[0]
                        )
                final_results.append(field_data)

        logger.info(
            f"Webhook request processed successfully, returning {len(results)} results"
        )
        return final_results

    def process_response_data(self, response, datastream):
        final_results = []

        for field in datastream["fields"]:
            results = []
            temp = {}
            for data in response:
                field_path = field["name"]
                logger.info(f"Processing field: {field_path}")
                logger.debug(f"Data: {data['_source']}")
                field_value = QueryBuilder.get_nested_field(
                    data["_source"], field_path, subfields=field.get("subfields")
                )

                if field_path == "timestamp.us":
                    field_value = datetime.datetime.fromtimestamp(field_value / 1000000)

                if field.get("unique", False) and temp in results:
                    pass
                else:
                    temp[field_path] = field_value
                    results.append(temp)
                logger.debug(f"Results: {results}")
            final_results.append(results)
        return final_results


app = Flask(__name__)
config = Config("config.yaml")
es_client = ElasticsearchClient(config)  # Ajustez l'URL selon votre configuration
webhook_handler = WebhookHandler(config, es_client)
config_data = config.get_global_config()


def flatten_json(data, prefix=""):
    items = []
    if isinstance(data, dict):
        for key, value in data.items():
            new_key = f"{prefix}.{key}" if prefix else key
            if isinstance(value, dict):
                items.extend(flatten_json(value, new_key))
            elif isinstance(value, list):
                items.append((new_key, str(value)))
            else:
                items.append((new_key, value))
    return items


def parse_nested_data(data, level=0):
    """
    Recursively parse nested lists and dictionaries to extract key-value pairs
    and print them with indentation based on the depth of the structure.

    Args:
    - data: The input data (list/dict) to be parsed.
    - level: The current level of nesting (used for indentation).
    """
    indent = "    " * level  # Define indentation based on the nesting level

    if isinstance(data, dict):
        for key, value in data.items():
            if isinstance(value, (dict, list)):
                print(f"{indent}{key}:")
                parse_nested_data(value, level + 1)
            else:
                print(f"{indent}{key}: {value}")

    elif isinstance(data, list):
        for item in data:
            parse_nested_data(item, level)


# Fonction pour générer le snippet HTML pour le format "row"
def generate_row_snippet(data):
    # Récupère le premier (et unique) élément du dictionnaire
    field_name = next(iter(data.keys()))
    values = next(iter(data.values()))

    # Récupère les clés (en-têtes) du premier élément
    if values and len(values) > 0:
        keys = values[0].keys()
    else:
        return "<p>No data available</p>"

    # Création du template avec la syntaxe Jinja2 correcte
    template = """
    <h2>{{ field_name|capitalize }}</h2>
    <table>
        <tr>
            {% for key in keys %}
            <th>{{ key|capitalize }}</th>
            {% endfor %}
        </tr>
        {% for item in values %}
        <tr>
            {% for value in item.values() %}
            <td>{{ value }}</td>
            {% endfor %}
        </tr>
        {% endfor %}
    </table>
    """

    # Rendu du template avec tous les paramètres nécessaires
    return render_template_string(
        template, field_name=field_name, keys=keys, values=values
    )


def generate_column_snippet(data):
    logger.debug(data)
    # Récupère le premier (et unique) élément du dictionnaire
    field_name = next(iter(data.keys()))
    values = next(iter(data.values()))

    # Vérification des données
    if not values:
        return "<p>No data available</p>"

    template = """
    <h2>{{ field_name|capitalize }}</h2>
    <table>
        <tr>
            <th>Field</th>
            <th>Value</th>
        </tr>
        {% for item in values %}
            {% for key, value in item.items() %}
                <tr>
                    <td>{{ key|capitalize }}</td>
                    <td>{{ value }}</td>
                </tr>
            {% endfor %}
        {% endfor %}
    </table>
    """

    return render_template_string(template, field_name=field_name, values=values)


def get_render_type(field_name, config_data: dict):
    # Loop through transaction_types and relevant datastreams
    for datastream in config_data.get("relevant_datastreams", []):
        # Loop through fields
        for field in datastream.get("fields", []):
            if field["name"] == field_name and "render_as" in field:
                return field["render_as"]
    return None


@app.route("/webhook", methods=["GET"])
def webhook():
    processor_keyword = request.args.get("processor_keyword")
    service_name = request.args.get("service_name")
    type_value = request.args.get("type_value")
    name = request.args.get("processor_value")
    start_date = request.args.get("from")
    end_date = request.args.get("to")

    processor = "span" if "span" in processor_keyword else "transaction"

    if not all([processor, type_value, name]):
        logger.error("Missing required parameters in webhook request")
        return jsonify({"error": "Missing parameters"}), 400

    logger.info(
        f"Received webhook request: processor={processor}, type={type_value}, name={name}"
    )

    results = webhook_handler.handle(
        processor, service_name, type_value, name, start_date, end_date
    )
    logger.debug(results)

    type_config = config.get_type_config(processor, type_value)

    snippets = []

    tables = []
    for result in results:
        if not result:
            continue
        logger.debug(result)
        values = []
        for field in result:
            data = {}
            for main_key, main_value in field.items():
                values.append(main_value)

            data[main_key] = values

        tables.append(data)

    for elt in tables:

        main_key = next(iter(elt.keys()))
        render_type = get_render_type(main_key, type_config) or "table_column"
        if render_type == "table_row":
            snippets.append(generate_row_snippet(elt))
        else:
            snippets.append(generate_column_snippet(elt))

    html_content = "\n".join(snippets)
    return f"""
    <html>
    <head>
        <style>
            table {{
                border-collapse: collapse;
                width: 100%;
                margin-bottom: 20px;
            }}
            th, td {{
                border: 1px solid #ddd;
                padding: 8px;
                text-align: left;
            }}
            th {{
                background-color: #4CAF50;
                color: white;
            }}
            tr:nth-child(even) {{background-color: #f2f2f2;}}
        </style>
    </head>
    <body>
        {html_content}
    </body>
    </html>
    """

    return render_template_string(html_content, snippets=snippets)


if __name__ == "__main__":
    logger.info("Starting webhook server")

    server_config = config_data.get("server", {})
    host = server_config.get("host", "127.0.0.1")
    port = server_config.get("port", 8080)
    debug = server_config.get("debug", False)
    logger.info(f"Starting server on {host}:{port}")

    ssl_data = config_data.get("ssl", {})
    if ssl_data.get("enabled", False):
        context = (ssl_data.get("cert_file"), ssl_data.get("key_file"))
        app.run(host=host, port=port, ssl_context=context, debug=debug)

    else:
        app.run(host=host, port=port, debug=debug)
