- # Evidence Collector Webhook

  ## Overview

  This project implements a Flask-based webhook server that integrates with Elasticsearch to handle and process incoming webhook requests from Kibana dashboards. The webhook receives drilldown URLs and captures evidence about events that are failing or taking longer than expected, for both transactions and spans.

  ## Features

  - Processes drilldown URLs from Kibana dashboards
  - Retrieves evidence fields and their values from Elasticsearch
  - Supports both transaction and span data
  - Configurable via YAML file

  ## Prerequisites

  - Python 3.7 or higher
  - pip (Python package installer)
  - Access to an Elasticsearch cluster
  - Kibana dashboard with configured drilldowns

  ## Installation

  ### 1. Create a Virtual Environment (Recommended):

  - **Linux/macOS:**

    ```bash
    python3 -m venv venv  # Replace "venv" with your desired environment name
    source venv/bin/activate  # Activate the virtual environment
    ```

  ### 2. Install the Wheel File and his Dependencies:

  **Dependencies installation in Air-Gapped Enviromment**

  Once the virtual environment is active, the following Process show you how to install all dependencies needed by the script

  ```
  tar -zxf dependecies.tar.gz
  ```

  ```
  pip3 install -r wheels/requirements.txt --no-index --find-links wheels
  ```

  ## Configuration

  ### Kibana Drilldown Configuration

  Configure your Kibana dashboard drilldowns using the following **template**:

  ```
  your_scheme://your_host:your_port/webhook?processor_keyword={{event.keys.[0]}}&service_name={{event.values.[2]}}&processor_value={{event.values.[0]}}&type_value={{event.values.[1]}}&from={{context.panel.timeRange.from}}&to={{context.panel.timeRange.to}}
  ```

  - `your_scheme`: The scheme of your webhook server (http or https)

  - `your_host`: The hostname or IP address of your webhook server

  - `your_port`: The port your webhook server is listening on

  - `processor_keyword`: Key of the event (span.name.keyword or transaction.name.keyword)

  - `service_name`: Name of the service

  - `processor_value`: Value of span.name or transaction.name

  - `type_value`: Type of the span or transaction (e.g., span.db or transaction.db)

  - `from` : start date context

  - `to`  : end date context

    


**Exemple** 

```
http://127.0.0.1:8080/webhook?processor_keyword=transaction.name.keyword&service_name=connectchrist&processor_value=GET%20api/events/$&type_value=request&from=now-30d/d&to=now
```



### YAML Configuration

Create a `config.yaml` file in the project root with the following structure:

```yaml
server:
  host: 127.0.0.1
  port: 8080
  log_level: DEBUG

ssl:
  enabled: true
  cert_file: /path/to/your/cert.pem
  key_file: /path/to/your/key.pem

elasticsearch:
  scheme: "https"
  host: "localhost"
  port: 9200
  username: "elastic"
  password: "your_password"

span_types:
  - name: db
    relevant_datastreams:
      - name: traces-apm*
        fields:
          - name: transaction
            subfields: [type, name, result, duration.us]
            unique: true
            render_as: "table_column"
          - name: service
            subfields: [name, environment]
            unique: true
          - name: url
            subfields: [full, path]
            unique: false
            render_as: "table_row"
        direct_association: true
        association_fields: 
        	- transaction.id
      # Add more datastreams as needed

transaction_types:
  - name: request
    relevant_datastreams:
      - name: traces-apm*
        fields:
          - name: transaction
            subfields: [type, name, result, duration.us]
            unique: true
            render_as: "table_column"
          - name: service
            subfields: [name, environment]
            unique: true
          - name: url
            subfields: [full, path]
            unique: false
            render_as: "table_row"
        direct_association: true
        association_fields: []
      - name: metrics-*
        fields:
          - name: host
            subfields: [name, os,ip]
            unique: false
            render_as: "table_row"
        direct_association: false
        association_fields:
          - host.ip
      - name: logs-*
        fields:
          - name: error
            subfields: [culprit, exception.]
            unique: true
            render_as: "table_row"
        direct_association: false
        association_fields:
          - transaction.id
      # Add more datastreams as needed
```

Adjust the values according to your environment and requirements.

### Fields Format in Datastreams

Each datastream contains various **fields** that can be configured with the following attributes:

- **`name`**:
  The identifier of the field. Example: `host`, `transaction`, `service`.

- **`subfields`**:
  A list of subfields within the field to capture. These subfields further define the data to be extracted.
  Example for `host`: `[name, ip, architecture, hostname]`.

- **`unique`** *(boolean)*:
  Determines whether the field should return only unique values.

  - `true`: Only unique values for the field will be returned.
  - `false`: All values, including duplicates, will be returned.

- **`render_as`** *(enum)*:
  Defines how the field values should be displayed in a table. The available options are:

  - **`table_row`**: Renders the field as a row-wise table, displaying values in rows.

    - **Example**:

      | Field name 1 | Field name 2 | Field name 3 |
      | ------------ | ------------ | ------------ |
      | Value 1.1    | Value 2.1    | Value 3.1    |
      | Value 1.2    | Value 2.2    | Value 3.2    |

  - **`table_column`**: Renders the field in a column-wise format, displaying field names as rows and their values as columns.

    - **Example**:

      | Field        | Value   |
      | ------------ | ------- |
      | Field name 1 | Value 1 |
      | Field name 2 | Value 2 |
      | Field name 3 | Value 3 |



## Running the Script

1. Ensure your Elasticsearch cluster is running and accessible.

2. Start the webhook server:
   ```
   python launch.py
   ```

3. The server will start and listen for incoming webhook requests based on the configuration in `config.yaml`.

## Usage

Once the server is running, it will process incoming webhook requests from your Kibana drilldowns. The webhook will query Elasticsearch based on the provided parameters and return evidence fields and their values related to the event in question.

## Troubleshooting

- If you encounter connection issues with Elasticsearch, verify the connection details in `config.yaml`.
- For webhook processing errors, check the server logs (configured log level in `config.yaml`).
- Ensure that the Kibana drilldown URLs are correctly formatted and contain all required parameters.
