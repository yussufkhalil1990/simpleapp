import yaml
import logging
import datetime
from flask import Flask, request, jsonify
from elasticsearch import Elasticsearch

# Configuration du logging
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s -   %(filename)s:%(lineno)d - %(message)s",
)
logger = logging.getLogger(__name__)


class Config:
    def __init__(self, yaml_file):
        with open(yaml_file, "r") as file:
            self.data = yaml.safe_load(file)
        logger.info(f"Configuration loaded from {yaml_file}")

    def get_type_config(self, processor, type):
        if processor == "span":
            config_type = self.data.get("span_types", [])
        elif processor == "transaction":
            config_type = self.data.get("transaction_types", [])
        else:
            logger.error(f"Unknown processor type: {processor}")
            return None

        for t in config_type:
            if t["name"] == type:
                return t
        logger.warning(f"No configuration found for type: {type}")
        return None

    def get_global_config(self):
        logger.info("Loading configurations from YAML file")
        try:
            with open("config.yaml", "r") as file:
                config = yaml.safe_load(file)
            logger.info("Configurations loaded successfully")
            return config
        except Exception as e:
            logger.error(f"Failed to load configurations: {e}")
            raise


class ElasticsearchClient:
    def __init__(self, conf: Config):
        logger.info("Connecting to Elasticsearch")
        config = conf.get_global_config()["elasticsearch"]

        configurations = {
            "basic_auth": (config.get("username"), config.get("password")),
        }
        self.client = Elasticsearch(
            hosts=f"{config.get('scheme')}://{config.get('host')}:{config.get('port')}/",
            **configurations,
            verify_certs=False,
        )

    def execute_query(self, index, query):
        try:
            logger.debug(f"Executing query {query}")
            response = self.client.search(index=index, body=query)
            hits = response["hits"]["hits"]
            logger.info(f"Query executed successfully on index {index}")
            # data = {hit["_id"]: hit["_source"] for hit in hits}
            if hits:
                data = hits[0]["_source"]
            else:
                data = {}
            logger.info(f"Data retrieved from index {data}")
            return data
        except Exception as e:
            logger.error(f"Error executing query on index {index}: {str(e)}")
            return {}


class QueryBuilder:
    @staticmethod
    def build_direct_query(service_name, processor_event, event_name, fields):
        attribut = "span.name" if processor_event == "span" else "transaction.name"

        return {
            "query": {
                "bool": {
                    "must": [
                        {"term": {"service.name": service_name}},
                        {"term": {f"{attribut}": event_name}},
                    ]
                }
            },
            "_source": fields,
        }

    @staticmethod
    def build_association_query(
        service_name, processor_event, event_name, association_field
    ):
        attribut = "span.name" if processor_event == "span" else "transaction.name"
        return {
            "query": {
                "bool": {
                    "must": [
                        {"term": {"service.name": service_name}},
                        {"term": {f"{attribut}": event_name}},
                    ]
                }
            },
            "_source": [association_field],
        }

    @staticmethod
    def get_nested_field(data, field_path):
        keys = field_path.split(".")
        current = data

        for key in keys:
            if isinstance(current, list):
                # If current is a list, accumulate the results from each list item
                result = []
                for item in current:
                    if isinstance(item, dict) and key in item:
                        result.append(item[key])
                    elif isinstance(item, list):  # Handle nested lists
                        result.extend(
                            [
                                sub_item.get(key)
                                for sub_item in item
                                if isinstance(sub_item, dict)
                            ]
                        )
                current = result
            elif isinstance(current, dict):
                current = current.get(key)
                if current is None:
                    return None
            else:
                return None

        return current


class WebhookHandler:
    def __init__(self, config, es_client):
        self.config = config
        self.es_client = es_client

    def handle(self, processor_event, service_name, type, event_name):
        logger.info(
            f"Handling webhook request: processor={processor_event}, type={type}, name={event_name}"
        )
        type_config = self.config.get_type_config(processor_event, type)
        if not type_config:
            logger.error(
                f"Configuration not found for processor={processor_event}, type={type}"
            )
            return {"error": "Configuration not found"}, 404

        final_results = []
        logger.debug(f"Type configuration: {type_config['relevant_datastreams']}")
        for datastream in type_config.get("relevant_datastreams", []):
            if datastream.get("direct_association", False):
                query = QueryBuilder.build_direct_query(
                    service_name,
                    processor_event,
                    event_name,
                    datastream["fields"],
                )
                logger.debug(f"Executing query: {query}")
                data = self.es_client.execute_query(datastream["name"], query)
                results = {}
                for field_path in datastream["fields"]:

                    results[field_path] = QueryBuilder.get_nested_field(
                        data, field_path
                    )
                    if field_path == "timestamp.us":
                        results[field_path] = datetime.datetime.fromtimestamp(
                            results[field_path] / 1000000
                        )

                final_results.append(results)
            else:
                association_query = QueryBuilder.build_association_query(
                    service_name,
                    processor_event,
                    event_name,
                    datastream.get("association_fields", []),
                )
                association_results_data = self.es_client.execute_query(
                    datastream["name"], association_query
                )
                association_results = {}
                results = {}
                for field_path in datastream["association_fields"]:
                    association_results[field_path] = QueryBuilder.get_nested_field(
                        association_results_data, field_path
                    )

                if association_results:
                    query = QueryBuilder.build_direct_query(
                        service_name,
                        processor_event,
                        event_name,
                        datastream["fields"],
                    )
                    data = self.es_client.execute_query(datastream["name"], query)
                    for field_path in datastream["fields"]:
                        results[field_path] = QueryBuilder.get_nested_field(
                            data, field_path
                        )
                        if field_path == "timestamp.us":
                            results[field_path] = datetime.datetime.fromtimestamp(
                                results[field_path] / 1000000
                            )
                    final_results.append(results)

        logger.info(
            f"Webhook request processed successfully, returning {len(results)} results"
        )
        return final_results


app = Flask(__name__)
config = Config("config.yaml")
es_client = ElasticsearchClient(config)  # Ajustez l'URL selon votre configuration
webhook_handler = WebhookHandler(config, es_client)
config_data = config.get_global_config()


@app.route("/webhook", methods=["GET"])
def webhook():
    processor_keyword = request.args.get("processor_keyword")
    service_name = request.args.get("service_name")
    type_value = request.args.get("type_value")
    name = request.args.get("processor_value")

    processor = "span" if "span" in processor_keyword else "transaction"

    if not all([processor, type_value, name]):
        logger.error("Missing required parameters in webhook request")
        return jsonify({"error": "Missing parameters"}), 400

    logger.info(
        f"Received webhook request: processor={processor}, type={type_value}, name={name}"
    )

    results = webhook_handler.handle(processor, service_name, type_value, name)
    return jsonify(results)


if __name__ == "__main__":
    logger.info("Starting webhook server")

    server_config = config_data.get("server", {})
    host = server_config.get("host", "127.0.0.1")
    port = server_config.get("port", 8080)
    logger.info(f"Starting server on {host}:{port}")
    app.run(host=host, port=port)
