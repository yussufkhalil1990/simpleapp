import requests

class KibanaClient:
    def __init__(self, host, port, scheme="http", username=None, password=None):
        self.base_url = f"{scheme}://{host}:{port}"
        self.session = requests.Session()

        # If you have authentication
        if username and password:
            self.session.auth = (username, password)

        self.session.headers.update(
            {"kbn-xsrf": "true", "Content-Type": "application/json"}
        )
        self.session.verify = False

    def get_index_patterns(self):
        """Retrieve all index patterns from Kibana."""
        url = f"{self.base_url}/api/data_views"
        response = self.session.get(url)
        response.raise_for_status()
        return response.json()

    def create_index_pattern(self, index_pattern_data):
        """Create a new index pattern in Kibana."""
        url = f"{self.base_url}/api/data_views/data_view"
        response = self.session.post(url, json=index_pattern_data)
        response.raise_for_status()
        return response.json()
    

    
    def get_saved_objects(self, type, id):
        """Retrieve a  saved object from Kibana."""
        url = f"{self.base_url}/api/saved_objects/{type}/{id}"
        response = self.session.get(url)
        response.raise_for_status()
        return response.json()

    def get_visualizations(self):
        """Retrieve all visualizations from Kibana."""
        url = f"{self.base_url}/api/saved_objects/_find?type=visualization"
        response = self.session.get(url)
        response.raise_for_status()
        return response.json()

    def get_dashboards(self):
        """Retrieve all dashboards from Kibana."""
        url = f"{self.base_url}/api/saved_objects/_find?type=dashboard"
        response = self.session.get(url)
        response.raise_for_status()
        return response.json()

    def create_dashboard(self, dashboard_data):
        """Create a new dashboard in Kibana."""
        url = f"{self.base_url}/api/saved_objects/dashboard"
        response = self.session.post(url, json=dashboard_data)
        response.raise_for_status()
        return response.json()
