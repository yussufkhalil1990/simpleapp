# Kibana Dashboard Launch Script

This script automates the process of creating Kibana dashboards from a template. It reads transaction details from a CSV file, creates an index pattern, and generates a new dashboard based on a specified template.

## Prerequisites 

- Python 3.6+
- Required Python packages (install via `pip install -r requirements.txt`):
  - argparse
  - pyyaml
  - requests
  - python-slugify

## Installation

### 1. Create a Virtual Environment (Recommended):

- **Linux/macOS:**

  ```bash
  python3 -m venv venv  # Replace "venv" with your desired environment name
  source venv/bin/activate  # Activate the virtual environment
  ```

- **Windows:**

  ```bash
  python -m venv venv  # Replace "venv" with your desired environment name
  venv\Scripts\activate  # Activate the virtual environment
  ```

### 2. Install the Wheel File and his Dependencies:

**Dependencies installation in Air-Gapped Enviromment**

Once the virtual environment is active, the following Process show you how to install all dependencies needed by the script

```
tar -zxf kibana-dashboard-dependecies.tar.gz
```

```
pip3 install -r wheels/requirements.txt --no-index --find-links wheels
```

## Configuration

### Config File (config.yaml)

Create a `config.yaml` file in the same directory as the script with the following structure:

```yaml
kibana:
  host: "your_kibana_host"
  port: 5601  # Default Kibana port
  username: "your_username"
  password: "your_password"
```

Replace the placeholders with your actual Kibana connection details.

### Input CSV File

Prepare an input CSV file with the following columns:

- `transaction`: The transaction name or identifier
- `dasboard_title`: The title for the new dashboard
- `dashboard_description`: A description for the new dashboard
- `template_id`: The ID of the template dashboard to use

Example:

```csv
transaction,dasboard_title,dashboard_description,template_id
transaction_1,My New Dashboard,This is a description of my dashboard,template_dashboard_id_123
```

## Usage

Run the script from the command line, providing the path to your input CSV file:

```
python launch_script.py -i path/to/your/input.csv
```

## How It Works

1. The script reads the configuration from `config.yaml`.
2. It parses the command-line arguments to get the input CSV file path.
3. Transaction details are read from the input CSV file.
4. An index pattern is created or retrieved based on the transaction name.
5. The script fetches the specified dashboard template.
6. A new dashboard is created using the template, with updated title, description, and index pattern.

## Troubleshooting

- Ensure all required Python packages are installed.
- Verify that the `config.yaml` file is correctly formatted and contains valid Kibana connection details.
- Check that the input CSV file exists and contains the required columns.
- If you encounter HTTP errors, verify your Kibana connection details and ensure you have the necessary permissions.

## Logging

The script logs information to stdout and errors to stderr. You can redirect these to files if needed:

```
python launch_script.py -i input.csv > output.log 2> error.log
```

For any issues or feature requests, please contact the development team.