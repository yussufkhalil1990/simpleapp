import argparse
import json
import logging
import sys
import csv
import yaml
from typing import Dict, Any

import requests
from slugify import slugify
from kibana_client import KibanaClient


class LaunchScript:
    def __init__(self):
        self.logger = self._setup_logger()
        # Load configuration from YAML file
        self.config = self.load_config("config.yaml")

        # Initialize KibanaClient with parameters from YAML file
        self.kibana_client = KibanaClient(
            host=self.config["kibana"]["host"],
            port=self.config["kibana"]["port"],
            scheme=self.config["kibana"]["scheme"],
            username=self.config["kibana"]["username"],
            password=self.config["kibana"]["password"],
        )

    def _setup_logger(self):
        logger = logging.getLogger(__name__)
        logger.setLevel(logging.INFO)

        default_handler = logging.StreamHandler(sys.stdout)

        error_handler = logging.StreamHandler(sys.stderr)
        error_handler.setLevel(logging.ERROR)

        formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )
        default_handler.setFormatter(formatter)
        error_handler.setFormatter(formatter)

        logger.addHandler(default_handler)
        logger.addHandler(error_handler)

        return logger

    def load_config(self, file_path):
        with open(file_path, "r") as file:
            return yaml.safe_load(file)

    def parse_arguments(self):
        parser = argparse.ArgumentParser(
            description="Create Kibana dashboard from template."
        )
        parser.add_argument(
            "-i", "--input", type=str, help="Input CSV file with transaction details"
        )
        return parser.parse_args()

    def replace_string_in_json(
        self, data: Any, target_string: str, replacement_string: str
    ) -> Any:
        json_str = json.dumps(data)
        updated_json_str = json_str.replace(target_string, replacement_string)
        return json.loads(updated_json_str)

    def update_dashboard_config(
        self,
        old_config: Dict[str, Any],
        new_index_id: str,
        new_title: str,
        new_description: str,
    ) -> Dict[str, Any]:
        config = old_config.copy()
        config["attributes"]["title"] = new_title
        config["attributes"]["description"] = new_description

        old_index_id = config["references"][0]["id"]

        # self.logger.info(f"Updated dashboard configuration: {config}")
        # fields to removes
        fields_to_remove = [
            "id",
            "type",
            "namespaces",
            "migrationVersion",
            "updated_at",
            "created_at",
            "version",
            "managed",
        ]
        for field in fields_to_remove:
            config.pop(field, None)

        config = self.replace_string_in_json(config, old_index_id, new_index_id)
        # self.logger.info(f"Updated dashboard configuration: {config}")
        return config

    def create_dashboard(
        self, transaction_name: str, title: str, description: str, template_id: str
    ):
        try:
            # Create index pattern
            index_pattern_data = {
                "name": f"data_view_{slugify(transaction_name)}",
                "title": f"eql_watcher_{slugify(transaction_name)}",
            }
            data_view = None
            all_index_patterns = self.kibana_client.get_index_patterns()

            for index_pattern in all_index_patterns["data_view"]:

                if index_pattern["title"] == index_pattern_data["title"]:
                    data_view = index_pattern
                    break

            if not data_view:
                data_view = self.kibana_client.create_index_pattern(index_pattern_data)

            self.logger.info(f"Created Index Pattern: {data_view['id']}")

            # Get dashboard template
            dashboard_template = self.kibana_client.get_saved_objects(
                "dashboard", template_id
            )
            self.logger.info(f"Retrieved Dashboard Template: {template_id}")

            # Update dashboard configuration
            new_dashboard_config = self.update_dashboard_config(
                dashboard_template, data_view["id"], title, description
            )

            # Create new dashboard
            created_dashboard = self.kibana_client.create_dashboard(
                new_dashboard_config
            )
            self.logger.info(f"Created Dashboard: {created_dashboard['id']}")

            return created_dashboard

        except requests.HTTPError as e:
            self.logger.error(
                f"HTTP Error: {e.response.status_code} - {e.response.text}"
            )
            raise

    def run(self):
        args = self.parse_arguments()

        # You might want to read transaction details from the input CSV file here
        # For now, we'll use the command-line arguments

        with open(args.input, mode="r") as file:
            csv_reader = csv.DictReader(file)
            for row in csv_reader:
                # Assuming the CSV has columns: 'transaction', 'title', 'description', 'template_id'
                transaction = row["transaction"]
                title = row["dasboard_title"]
                description = row["dashboard_description"]
                template_id = row["template_id"]

                created_dashboard = self.create_dashboard(
                    transaction, title, description, template_id
                )

                self.logger.info(
                    f"Successfully created dashboard: {created_dashboard['id']}"
                )


if __name__ == "__main__":
    LaunchScript().run()
