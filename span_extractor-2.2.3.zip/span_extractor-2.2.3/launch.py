import json
import argparse
import logging
import csv
from datetime import datetime
from span_extractor import SpanExtractor
from watcher_script import WatcherWorker
from utils import get_configurations
from slugify import slugify
from pprint import pprint


class LaunchScript:
    def __init__(self):
        self.setup_logger()
        self.logger = logging.getLogger("launch_script")
        self.extractor = SpanExtractor()

    def setup_logger(self):
        logger = logging.getLogger("central_logger")
        logger.setLevel(logging.DEBUG)

        default_handler = logging.FileHandler("logs/default.log")
        error_handler = logging.FileHandler("logs/error.log")
        error_handler.setLevel(logging.ERROR)

        formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )
        default_handler.setFormatter(formatter)
        error_handler.setFormatter(formatter)

        logger.addHandler(default_handler)
        logger.addHandler(error_handler)

    def parse_arguments(self):
        parser = argparse.ArgumentParser(description="Process some value.")
        parser.add_argument(
            "-i",
            "--input",
            type=str,
            help="Output file where to save the result, a CSV file",
        )
        return parser.parse_args()

    def process_file(self, input_file):
        with open(input_file, "r") as file:
            reader = csv.reader(file)
            next(reader)
            for row in reader:
                span_name = row[0]
                start_time = row[1] or None
                end_time = row[2] or None
                number_of_traces = int(row[3]) or None
                service_name = row[4] or None

                name_slug = slugify(span_name)
                global_output = f"clusters/{name_slug}_cluster.json"

                self.logger.info(f"Processing span: {span_name}")
                cluster = self.extractor.traversal(
                    span_name, [start_time, end_time], number_of_traces, global_output
                )
                self.triplets = []
                # with open("clusters/get-api-schema_cluster.json", "r") as file:
                #     cluster = json.load(file)

                self.process_cluster(cluster, span_name, service_name)

    def sort_by_timestamp(self, data):
        # Convert the timestamp string to a datetime object for sorting
        sorted_data = sorted(
            data,
            key=lambda x: datetime.fromisoformat(x[0]["timestamp"].replace("Z", "")),
        )
        return sorted_data

    # def process_cluster(self, cluster, span_name, service_name):
    #     i = 1
    #     for key, data in cluster.items():
    #         pattern = data["pattern"]

    #         # relations = self.extractor.create_relations(pattern)
    #         # descendance = self.extractor.trace_hierarchical_descent(relations)
    #         # sorted_data = pattern[::-1]
    #         eql_config = get_configurations().get("eql_query", {})
    #         time_range = eql_config.get("time_range", "4h")
    #         size = eql_config.get("size", 100)
    #         eql_query = self.extractor.generate_eql_query(
    #             pattern, service_name, span_name, time_range=time_range, size=size
    #         )

    #         watcher = WatcherWorker(
    #             span_name=span_name + "Pattern" + str(i),
    #             service_name=service_name,
    #             eql_query=eql_query,
    #             eql_index_name=f"eql_watcher_{slugify(span_name)}",
    #         )
    #         watcher.config = get_configurations()
    #         watcher.create_update_watcher()

    #         self.logger.info(f"Created watcher for pattern {i} of span: {span_name}")
    #         i += 1

    def process_cluster(self, cluster, span_name, service_name):
        eql_config = get_configurations().get("eql_query", {})
        time_range = eql_config.get("time_range", "4h")
        size = eql_config.get("size", 100)

        # Process the first pattern
        first_key = next(iter(cluster))
        first_pattern = cluster[first_key]["pattern"]

        eql_query = self.extractor.generate_eql_query(
            first_pattern, service_name, span_name, time_range=time_range, size=size
        )

        watcher = WatcherWorker(
            span_name=f"{span_name}Pattern1",
            service_name=service_name,
            eql_query=eql_query,
            eql_index_name=f"eql_watcher_{slugify(span_name)}",
        )
        watcher.config = get_configurations()
        watcher.create_update_watcher()

        self.logger.info(f"Created watcher for first pattern of span: {span_name}")

        # Record the triplet for the first pattern
        initial_transaction = first_pattern[0][0]["span.name"]
        final_transaction = first_pattern[-1][1]["span.name"]
        interm_transaction = len(first_pattern) - 2
        self.record_triplet(initial_transaction, final_transaction, interm_transaction)

        # Process the remaining patterns
        for i, (key, data) in enumerate(list(cluster.items())[1:], start=2):
            pattern = data["pattern"]

            # Check if the triplet already exists
            initial_transaction = pattern[0][0]["span.name"]
            final_transaction = pattern[-1][1]["span.name"]
            interm_transaction = len(pattern) - 2
            if self.triplet_exists(
                initial_transaction, final_transaction, interm_transaction
            ):
                self.logger.info(
                    f"Triplet already exists for pattern {i} of span: {span_name}. Skipping."
                )
                continue

            # Create a new watcher for this pattern
            eql_query = self.extractor.generate_eql_query(
                pattern, service_name, span_name, time_range=time_range, size=size
            )

            watcher = WatcherWorker(
                span_name=f"{span_name}Pattern{i}",
                service_name=service_name,
                eql_query=eql_query,
                eql_index_name=f"eql_watcher_{slugify(span_name)}",
            )
            watcher.config = get_configurations()
            watcher.create_update_watcher()

            self.logger.info(f"Created watcher for pattern {i} of span: {span_name}")

            # Record the new triplet
            self.record_triplet(
                initial_transaction, final_transaction, interm_transaction
            )

    def record_triplet(self, initial_transaction, final_transaction, run_type):
        """
        Record a new triplet in the set of existing triplets.

        Args:
        initial_transaction (str): The initial transaction of the pattern.
        final_transaction (str): The final transaction of the pattern.
        run_type (str): The type of run, e.g., "with run".
        """
        triplet = (initial_transaction, final_transaction, run_type)
        print(triplet)
        self.triplets.append(triplet)
        self.logger.info(f"Recorded new triplet: {triplet}")

    def triplet_exists(self, initial_transaction, final_transaction, run_type):
        """
        Check if a triplet already exists in the set of recorded triplets.

        Args:
        initial_transaction (str): The initial transaction of the pattern.
        final_transaction (str): The final transaction of the pattern.
        run_type (str): The type of run, e.g., "with run".

        Returns:
        bool: True if the triplet exists, False otherwise.
        """
        triplet = (initial_transaction, final_transaction, run_type)
        pprint(self.triplets)
        exists = triplet in self.triplets
        if exists:
            self.logger.info(f"Triplet {triplet} already exists")
        return exists

    def run(self):
        args = self.parse_arguments()
        self.process_file(args.input)


if __name__ == "__main__":
    launch_script = LaunchScript()
    launch_script.run()
