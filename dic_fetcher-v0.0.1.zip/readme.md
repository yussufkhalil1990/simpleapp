## DicFilesFetcher - v0.0.1 - A Script to Download DIC Files on nautobot-sever

This script fetches DIC files from a Nautobot server and downloads them to a specified directory. It also keeps track of the last execution time to avoid downloading duplicate files.

### Prerequisites

- Python 3.x
- Requests library (`pip install requests`)
- Logging library (`pip install logging`)

### Usage

1. **Download the script.**
2. **Install required libraries:** Open a terminal or command prompt and navigate to the directory containing the script (`script.py`) and its dependencies. Then, run:

Bash

```
pip install requests logging
```

1. Run the script:
   - Open a terminal or command prompt and navigate to the directory containing the script.
     -  `-d` or `--dir` argument specifying the directory where you want to download the DIC files 
     - `-u` or `--url` **(optional)** argument specifying the base url of nautobot server, the default value is `http://127.0.0.1:8000` . For example:

Bash

```
python script.py -d /path/to/download/directory -u http://some-url:port
```

**Replace `/path/to/download/directory` with the actual directory path where you want to store the downloaded files.**

### Explanation of Arguments:

- `-d` or `--dir`: This argument takes the path to the directory where you want to download the DIC files.
- `-u` or `--url` :  Optional argument, represent base url of nautobot server

### Script Output

The script will print one of the following messages to the console depending on the outcome:

- `"Success"`: The script successfully fetched and downloaded the DIC files.
- `"Failed"`: An error occurred during the download process. Check the log file for details.

### Logging

The script uses Python's logging module to record its actions and any errors encountered. Logs are written to a file named `dic_fetcher.log` in the same directory as the script.

