#!/home/main-c/Documents/Projets/PythonProjects/IBAASProject/span_extractor/span-extractor/dist/.env/bin/python3
import json
import logging
import hashlib
from elasticsearch import Elasticsearch
from typing import Any, Dict, List, Tuple
from pprint import pprint
from slugify import slugify
from utils import connect_to_elasticsearch
from itertools import groupby
from collections import deque
from collections import defaultdict
from datetime import datetime


class SpanExtractor:

    def __init__(self):
        # Create a handler
        stream_handler = logging.StreamHandler()
        file_handler = logging.FileHandler("span_extractor.log")

        formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(filename)s:%(lineno)d - %(levelname)s - %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
        stream_handler.setFormatter(formatter)
        file_handler.setFormatter(formatter)
        self.logger = logging.getLogger("SpanExtractor")
        self.logger.addHandler(stream_handler)
        self.logger.addHandler(file_handler)
        self.logger.setLevel(logging.DEBUG)
        self.logger.info("SpanExtractor initialized")
        self.es_client = connect_to_elasticsearch()

    def match_columns_and_values(self, data):
        self.logger.info("Matching columns and values")
        columns = [col["name"] for col in data["columns"]]
        values = data["values"]

        result = []
        for value in values:
            row_dict = dict(zip(columns, value))
            result.append(row_dict)

        self.logger.info("Matched columns and values")
        return result

    def extract_entry_span(
        self, name: str, time_interval: list, number_of_traces: int = 10
    ) -> Dict[str, Any]:
        self.logger.info(f"Extracting entry span for {name}")

        query = """
        FROM traces-apm*
        | WHERE transaction.name == "{span_name}"
        | WHERE @timestamp >="{start_date}"
        | WHERE @timestamp <="{end_date}"
        | KEEP span.id, span.name, transaction.id, transaction.name, processor.event, trace.id, parent.id, @timestamp, service.name, timestamp.us
        | LIMIT {number_of_traces}
        """.format(
            span_name=name,
            start_date=time_interval[0],
            end_date=time_interval[1],
            number_of_traces=number_of_traces,
        )
        self.logger.info(f"Query: {query}")
        try:
            response = self.es_client.esql.query(
                query=query,
                format="json",
            )
            self.logger.info(f"Response: {response.body}")
            entry_span = self.match_columns_and_values(response.body)
            self.logger.info(f"Entry span: {entry_span}")
            if len(entry_span) == 0:
                raise Exception("No entry span found")
            return entry_span
        except Exception as e:
            self.logger.error(f"Failed to query Elasticsearch: {e}")
            raise

    def extract_children_spans(self, span_id: str) -> List[Dict[str, Any]]:
        self.logger.info(f"Extracting children spans for span_id: {span_id}")

        query = """
            FROM traces-apm* 
            | WHERE parent.id == "{span_id}" 
            | KEEP span.id, span.name, transaction.id, transaction.name, processor.event, trace.id, parent.id, @timestamp, service.name, timestamp.us
            """.format(
            span_id=span_id
        )
        self.logger.info(f"Query: {query}")
        try:
            response = self.es_client.esql.query(
                query=query,
                format="json",
            )
            self.logger.info(f"Response: {response.body}")
            children_spans = self.match_columns_and_values(response.body)
            self.logger.info(f"Children spans: {children_spans}")
            return children_spans
        except Exception as e:
            self.logger.error(f"Failed to query Elasticsearch: {e}")
            raise

    def get_span_pairs(
        self, span: Dict[str, Any]
    ) -> List[Tuple[Dict[str, Any], Dict[str, Any]]]:
        self.logger.info(f"Getting span pairs for span: {span}")
        span_pairs = []
        children_spans = self.extract_children_spans(span["span.id"])
        for child_span in children_spans:
            span_pairs.append((span, child_span))
            grand_children_pairs = self.get_span_pairs(child_span)
            span_pairs.extend(grand_children_pairs)
        self.logger.info(f"Span pairs: {span_pairs}")
        return span_pairs

    def hash_pattern(self, pattern: Dict[str, Any]) -> str:
        self.logger.info(f"Hashing pattern: {pattern}")
        pattern_str = json.dumps(pattern, sort_keys=True)
        pattern_hash = hashlib.md5(pattern_str.encode("utf-8")).hexdigest()
        self.logger.info(f"Pattern hash: {pattern_hash}")
        return pattern_hash

    def store_patterns(self, spans: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
        self.logger.info("Storing patterns")
        cluster = {}
        patterns = []
        for pattern in spans:
            if pattern in patterns:
                # Find the hash for the existing pattern and update its count
                for pattern_hash, data in cluster.items():
                    if data["pattern"] == pattern:
                        cluster[pattern_hash]["count"] += 1
                        break
                continue

            pattern_hash = self.hash_pattern(pattern)
            if pattern_hash not in cluster:
                cluster[pattern_hash] = {"pattern": pattern, "count": 1}
            else:
                cluster[pattern_hash]["count"] += 1

            patterns = [data["pattern"] for data in cluster.values()]
            pprint(pattern)

        self.logger.info(f"Stored patterns: {cluster}")
        return cluster

    def extract_values(self, data):
        self.logger.info("Extracting values")
        result = []
        for pair in data:
            temp = []
            for item in pair:
                span_name = (
                    item["span.name"]
                    if item["span.name"] is not None
                    else item["transaction.name"]
                )
                processor_event = item["processor.event"]
                timestamp = item["@timestamp"]
                temp.append(
                    {
                        "span.name": span_name,
                        "processor.event": processor_event,
                        "timestamp": timestamp,  # Keep timestamp for sorting
                    }
                )

            # # Remove timestamp from each item after sorting
            # for item in temp:
            #     del item["timestamp"]

            result.append((temp[0], temp[1]))
        # Sort the result by timestamp before removing the timestamp key
        result = sorted(result, key=lambda pair: pair[1].get("timestamp", ""))
        # Remove timestamp from each item after sorting
        for pair in result:
            for item in pair:
                if "timestamp" in item:
                    del item["timestamp"]

        self.logger.info(f"Extracted values: {result}")
        return result

    def traversal(
        self, name: str, time_interval, number_of_traces: int, output_file: str
    ) -> List[Tuple[Dict[str, Any], Dict[str, Any]]]:
        self.logger.info(f"Starting traversal for {name}")
        spans = []
        cluster = {}
        trace_ids = []
        i = 1

        entry_spans = self.extract_entry_span(name, time_interval, number_of_traces)
        for entry_span in entry_spans:
            if entry_span["trace.id"] in trace_ids:
                self.logger.info(f"Duplicate trace id found: {entry_span['trace.id']}")
                continue
            else:
                trace_ids.append(entry_span["trace.id"])
                span_pairs = self.get_span_pairs(entry_span)
                spans.append(self.extract_values(span_pairs))
        self.logger.info(f"Evaluated trace ids: {trace_ids}")

        cluster = self.store_patterns(spans)

        with open(output_file, "w") as f:
            json.dump(cluster, f)
        self.logger.info(f"Traversal completed and output saved to {output_file}")

        return cluster

    def generate_digraph(self, cluster: Dict[str, Any], output_file: str):
        self.logger.info(f"Generating digraph for cluster")
        i = 1
        for key in cluster.keys():
            span_pairs = json.loads(key)

            input = []
            for pair in span_pairs:
                parent_span_name = pair[0]["span.name"]
                child_span_name = pair[1]["span.name"]
                input.append((parent_span_name, child_span_name))

            filename = f"cluster{i}_digraph.json"
            with open(filename, "w") as f:
                json.dump(input, f)
                i += 1
        self.logger.info(f"Digraph generated and saved to {output_file}")

    def create_relations(self, data):

        sorted_data = sorted(data, key=lambda pair: pair[1]["timestamp"])

        relations = defaultdict(list)
        for pair in sorted_data:
            parent = (
                pair[0]["span.name"],
                pair[0]["processor.event"],
                pair[0]["timestamp"],
            )
            child = (
                pair[1]["span.name"],
                pair[1]["processor.event"],
                pair[1]["timestamp"],
            )
            relations[parent].append(child)
        return relations

    def trace_hierarchical_descent(self, relations):
        descendance = []
        visited = set()

        def traverse(key):
            # if key not in visited:
            visited.add(key)
            descendance.append(key)

            # Sort children by timestamp, oldest first
            children = sorted(relations.get(key, []), key=lambda x: x[2])

            for child in children:
                traverse(child)

        # Find root nodes (nodes that are not children of any other node)
        all_children = set(
            child[:2] for children in relations.values() for child in children
        )
        root_nodes = set(key for key in relations.keys() if key[:2] not in all_children)

        # Start the traversal from each root node
        for root in root_nodes:
            traverse(root)

        pprint(descendance)
        return descendance

    def generate_eql_query1(
        self, spans, service_name, transaction_name, time_range="4h", size=500
    ):
        self.logger.info(
            f"Generating EQL query for service: {service_name}, transaction: {transaction_name}"
        )
        sequence = [
            f'any where service.name == "{service_name}" and transaction.name == "{transaction_name}"'
        ]

        for span_name, event_type, timestamp in spans:
            if event_type == "transaction":
                sequence.append(f'any where transaction.name == "{span_name}"')
            else:
                sequence.append(f'any where span.name == "{span_name}"')

        sequence_query = " ] [ ".join(sequence)
        query_body = {
            "query": f"sequence by trace.id [ {sequence_query} ]",
            "fields": [
                "transaction.name",
                "span.name",
                "transaction.duration.us",
                "span.duration.us",
                "processor.event",
                "event.outcome",
                "parent.id",
                "trace.id",
            ],
            "filter": {
                "range": {"@timestamp": {"gte": f"now-{time_range}", "lte": "now"}}
            },
            "size": size,
        }
        eql_query = json.dumps(query_body)
        self.logger.info(f"EQL query generated: {eql_query}")
        return eql_query

    def generate_eql_query(
        self,
        couple,
        service_name,
        transaction_name,
        time_range="4h",
        size=500,
        eql_type="latency",
        transaction_duration=1000000,
    ):
        self.logger.info(
            f"Generating EQL query for service: {service_name}, transaction: {transaction_name}"
        )
        if eql_type == "latency":
            first_sequence = f'any where service.name == "{service_name}" and transaction.name == "{transaction_name}" and transaction.duration.us > {transaction_duration}'
        else:
            first_sequence = f'any where service.name == "{service_name}" and transaction.name == "{transaction_name}" and event.outcome == "failure"'

        if couple:
            sequence = []
            span_name = couple[0]
            event_number = couple[1]
            if event_number == 1:

                sequence.append(f'any where span.name == "{span_name}"')
                sequence_query = " ] [ ".join(sequence)
                query = (
                    f"sequence by trace.id [ {first_sequence} ] [ {sequence_query} ]"
                )

            else:
                if event_number > 2:
                    second_sequence = f"[ any where true ] with runs={event_number}"
                else:
                    second_sequence = "[ any where true ]"

                sequence.append(f'any where span.name == "{span_name}"')

                sequence_query = " ] [ ".join(sequence)
                query = f"sequence by trace.id [ {first_sequence} ] {second_sequence} [ {sequence_query} ]"
        else:
            second_sequence = "[ any where true ]"
            query = f"sequence by trace.id [ {first_sequence} ] {second_sequence}"

        query_body = {
            "query": query,
            "fields": [
                "transaction.name",
                "span.name",
                "transaction.duration.us",
                "span.duration.us",
                "processor.event",
                "event.outcome",
                "parent.id",
                "trace.id",
            ],
            "filter": {
                "range": {"@timestamp": {"gte": f"now-{time_range}", "lte": "now"}}
            },
            "size": size,
        }
        eql_query = json.dumps(query_body)
        self.logger.info(f"EQL query generated: {eql_query}")
        return eql_query
