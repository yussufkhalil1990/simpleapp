import json
import argparse
import logging
import csv
from datetime import datetime
from span_extractor import SpanExtractor
from watcher_script import WatcherWorker
from utils import get_configurations
from slugify import slugify
from pprint import pprint


class LaunchScript:
    def __init__(self):
        self.setup_logger()
        self.logger = logging.getLogger("launch_script")
        self.extractor = SpanExtractor()

    def setup_logger(self):
        logger = logging.getLogger("central_logger")
        logger.setLevel(logging.DEBUG)

        default_handler = logging.FileHandler("logs/default.log")
        error_handler = logging.FileHandler("logs/error.log")
        error_handler.setLevel(logging.ERROR)

        formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )
        default_handler.setFormatter(formatter)
        error_handler.setFormatter(formatter)

        logger.addHandler(default_handler)
        logger.addHandler(error_handler)

    def parse_arguments(self):
        parser = argparse.ArgumentParser(description="Process some value.")
        parser.add_argument(
            "-i",
            "--input",
            type=str,
            help="Output file where to save the result, a CSV file",
        )
        return parser.parse_args()

    def process_file(self, input_file):
        with open(input_file, "r") as file:
            reader = csv.reader(file)
            next(reader)
            for row in reader:
                span_name = row[0]
                start_time = row[1] or None
                end_time = row[2] or None
                number_of_traces = int(row[3]) or None
                service_name = row[4] or None
                self.transaction_duration = row[5] or None

                name_slug = slugify(span_name)
                global_output = f"clusters/{name_slug}_cluster.json"

                self.logger.info(f"Processing span: {span_name}")
                cluster = self.extractor.traversal(
                    span_name, [start_time, end_time], number_of_traces, global_output
                )

                # with open("clusters/get-api-schema_cluster.json", "r") as file:
                #     cluster = json.load(file)

                self.process_cluster(cluster, span_name, service_name)

    def sort_by_timestamp(self, data):
        # Convert the timestamp string to a datetime object for sorting
        sorted_data = sorted(
            data,
            key=lambda x: datetime.fromisoformat(x[0]["timestamp"].replace("Z", "")),
        )
        return sorted_data

    def process_cluster(self, cluster, span_name, service_name):
        eql_config = get_configurations().get("eql_query", {})
        time_range = eql_config.get("time_range", "4h")
        size = eql_config.get("size", 100)

        # Building couples for each pattern
        self.existing_couples = []

        print(f"Total patterns in cluster: {len(cluster)}")  # Debug print
        for key, data in list(cluster.items()):
            pattern = data["pattern"]
            if pattern:
                final_transaction = pattern[-1][1]["span.name"]
                interm_transaction = len(pattern) - 1
                if interm_transaction > 99:
                    continue
                couple = (final_transaction, interm_transaction)
            else:
                couple = ()
            print(f"This is couple: {couple}")
            self.existing_couples.append(couple)

        print(f"Total couples created: {len(self.existing_couples)}")  # Debug print

        unique_couples = set(self.existing_couples)
        print(f"Number of unique couples: {len(unique_couples)}")  # Debug print
        # Save all existing couples after processing all patterns
        with open(f"logs/{slugify(span_name)}unique_couples.json", "w") as file:
            json.dump(list(unique_couples), file)

        pattern_counter = 1
        for couple in unique_couples:
            print(f"Processing couple: {couple}")  # Debug print

            # Create a new watcher latency for this pattern
            eql_query = self.extractor.generate_eql_query(
                couple,
                service_name,
                span_name,
                time_range=time_range,
                size=size,
                transaction_duration=self.transaction_duration,
            )

            watcher = WatcherWorker(
                span_name=f"{span_name}Pattern{pattern_counter}",
                service_name=service_name,
                eql_query=eql_query,
                eql_index_name=f"eql_watcher_{slugify(span_name)}",
            )
            watcher.config = get_configurations()
            watcher.create_update_watcher()

            self.logger.info(
                f"Created watcher for pattern {pattern_counter} of span: {span_name}"
            )
            # Increment the counter only for patterns that were not skipped
            pattern_counter += 1

        print(f"Total watchers created: {pattern_counter - 1}")  # Debug print

    print("Process completed")  # Debug print

    def run(self):
        args = self.parse_arguments()
        self.process_file(args.input)


if __name__ == "__main__":
    launch_script = LaunchScript()
    launch_script.run()
