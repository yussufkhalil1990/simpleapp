from elasticsearch import Elasticsearch
import yaml
import logging

logger = logging.getLogger("central_logger")


def connect_to_elasticsearch() -> Elasticsearch:
    logger.info("Connecting to Elasticsearch")
    config = get_configurations()["elasticsearch"]

    configurations = {
        "basic_auth": (config.get("username"), config.get("password")),
    }
    es = Elasticsearch(
        hosts=f"{config.get('scheme')}://{config.get('host')}:{config.get('port')}/",
        **configurations,
        verify_certs=False,
    )
    return es


def get_configurations():
    logger.info("Loading configurations from YAML file")
    try:
        with open("config_file.yaml", "r") as file:
            config = yaml.safe_load(file)
        logger.info("Configurations loaded successfully")
        return config
    except Exception as e:
        logger.error(f"Failed to load configurations: {e}")
        raise
