# Span Extractor v2.3.2 Release Notes

## New Features

### Unified Watcher Instance
- A single watcher instance is now created for all patterns.
- The EQL query within the watcher has been modified to accommodate multiple patterns.
- A new condition has been added to the leading transaction to filter based on two criteria:
  1. Exclude event.outcome failures
  2. Filter out transactions where duration (dur.us) exceeds a specified threshold

### Configurable Duration Threshold
- The duration threshold can now be set in the input.csv file, allowing for easy customization per deployment.

## Enhancements

### Pattern Limit Implementation
- To prevent errors caused by excessive sequence length, patterns with more than 98 intermediate transactions are now automatically ignored.
- This enhancement ensures system stability and prevents potential issues with overly complex patterns.

## Changes from Previous Version

- The separate availability and latency watchers have been consolidated into a single, more efficient watcher instance.
- The new filtering condition on the leading transaction replaces the previous separate checks for availability and latency.

## Notes for Users

- Review and update your input.csv file to include the new duration threshold setting for optimal performance.
- Patterns with a high number of intermediate transactions (>98) will no longer be processed. Consider simplifying these patterns if necessary.
- The unified watcher approach may require adjustments to any custom integrations or workflows built around the previous dual-watcher system.
