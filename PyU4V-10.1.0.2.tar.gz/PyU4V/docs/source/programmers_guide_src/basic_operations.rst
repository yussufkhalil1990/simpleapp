Basic Operations
================

First connection to PyU4V
-------------------------

In this basic example we initialise a connection with Unisphere, retrieving
version and array information, and finishing by closing the REST session.

.. literalinclude:: code/basic-unisphere_connect.py
    :linenos:
    :language: python
    :lines: 14-47
