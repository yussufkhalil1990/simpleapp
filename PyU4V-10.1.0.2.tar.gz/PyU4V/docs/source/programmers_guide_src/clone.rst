Clone
======
This section gives examples of the following system functionality:

- `Create and Manage Clones`_


Create and Manage Clones
------------------------
This example of replication calls demonstrates how to create independent
copies of your data using clone technology, for more detail on working with
TimeFinder Clone please see Dell Solutions Enabler 10.0.0 TimeFinder/
Clone CLI User Guide available on https://support.dell.com.

.. literalinclude:: code/clone.py
    :linenos:
    :language: python
    :lines: 14-34

.. literalinclude:: code/restoreclone.py
    :linenos:
    :language: python
    :lines: 14-18
