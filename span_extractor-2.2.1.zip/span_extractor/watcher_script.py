import logging
from elasticsearch import Elasticsearch
from typing import Any, Dict, List, Tuple
from pprint import pprint
from slugify import slugify
from utils import connect_to_elasticsearch


class WatcherWorker:

    def __init__(
        self, span_name: str, service_name: str, eql_query, eql_index_name: str
    ):
        self.watcher_name = f"{slugify(span_name)}_watcher"
        self.watcher_id = self.watcher_name
        self.logger = logging.getLogger("WatcherWorker")
        self.span_name = span_name
        self.service_name = service_name
        self.eql_query = eql_query
        self.eql_index_name = eql_index_name
        self.logger.info(
            f"Initialized WatcherWorker for span: {span_name}, service: {service_name}"
        )

    def get_trigger(self):
        self.logger.info("Getting trigger configuration")
        trigger_time = self.config.get("trigger_time", "5m")
        self.logger.info(f"Trigger time: {trigger_time}")
        return {"schedule": {"interval": "{}".format(trigger_time)}}

    def get_condition(self):
        self.logger.info("Getting condition configuration")
        return {"always": {}}

    def get_actions(self):
        self.logger.info("Getting actions configuration")
        return {"index-action": {"index": {"index": self.eql_index_name}}}

    def get_input(self):
        self.logger.info("Getting input api configuration")
        try:
            http_input = self.config.get("http_input", {})
            headers = {
                # "Content-Type": "application/json",
                "Authorization": http_input.get("api_key"),
            }

            input = {
                "http": {
                    "request": {
                        "scheme": http_input["scheme"] or "https",
                        "host": http_input["host"],
                        "port": http_input["port"],
                        "method": "get",
                        "path": "traces-apm-default/_eql/search",
                        "headers": headers,
                        "body": self.eql_query,
                        "read_timeout_millis": 240000,
                    }
                }
            }
            self.logger.info("Input configuration created successfully")
            return input
        except Exception as e:
            self.logger.error(f"Failed to get input configuration: {e}")
            raise

    def get_transform(self):
        self.logger.info("Getting transform configuration")
        return {
            "script": {
                "source": """
        def final_event_list = [];
        
        for (def sequence: ctx.payload.hits.sequences) {
          def join_keys = sequence.join_keys;
          def sequenceId = UUID.randomUUID().toString(); // Generate a unique sequence ID;
          def trace_id = join_keys[0];
          for (def event: sequence.events) {
            def span_id = event._source.span.id;
            event["_source"]["join_keys"]= join_keys;
            event["_source"]["sequenceId"]= sequenceId;
            def custom_id = trace_id + "_" + span_id;
            event["_id"] = custom_id;
            final_event_list.add(event["_source"]);
          }
        }
        
        return ['_doc': final_event_list];
        """,
                "lang": "painless",
            }
        }

    #     return {
    #         "script": {
    #             "source": """
    #     def final_event_list = [];
    #     def fields_to_keep = [
    #       "transaction",
    #       "span",
    #       "processor",
    #       "service",
    #       "trace",
    #       "event"

    #     ];

    #     for (def sequence : ctx.payload.hits.sequences) {
    #       def join_keys = sequence.join_keys;
    #       def sequenceId = UUID.randomUUID().toString();
    #       def trace_id = join_keys[0];
    #       for (def event : sequence.events) {
    #         def span_id = event._source.span?.id ?: UUID.randomUUID().toString();
    #         event._source.join_keys = join_keys;
    #         event._source.sequenceId = sequenceId;
    #         def custom_id = trace_id + "_" + span_id;
    #         event._id = custom_id;

    #         def new_source = [:];
    #         for (def field : fields_to_keep) {
    #           if (event._source.containsKey(field)) {
    #             new_source[field] = event._source[field];
    #           }
    #         }

    #         final_event_list.add(new_source);
    #       }
    #     }

    #     return ['_doc': final_event_list];
    #   """,
    #             "lang": "painless",
    #         }
    #     }

    def get_metadata(self):
        self.logger.info("Getting metadata configuration")
        return {"type": "eql-watcher"}

    def create_update_watcher(self):
        self.logger.info(f"Creating/updating watcher: {self.watcher_name}")
        es_client = connect_to_elasticsearch()
        watcher_client = es_client.watcher
        

        try:
            res = watcher_client.put_watch(
                id=self.watcher_id,
                trigger=self.get_trigger(),
                condition=self.get_condition(),
                actions=self.get_actions(),
                input=self.get_input(),
                transform=self.get_transform(),
                metadata=self.get_metadata(),
            )
            self.logger.info(
                f"Watcher {self.watcher_name} created/updated successfully"
            )
            self.logger.info(res.body)
            print(res.body)
        except Exception as e:
            self.logger.error(
                f"An error occurred when creating/updating {self.watcher_name}: {e}"
            )
            raise


# if __name__ == "__main__":
#     worker = WatcherWorker("POST api/auth/signup/$", "", {})
#     worker.get_configurations()
#     pprint(worker.get_input())
#     worker.create_update_watcher()
