import json
import argparse
import logging
import csv
from datetime import datetime
from span_extractor import SpanExtractor
from watcher_script import WatcherWorker
from utils import get_configurations
from slugify import slugify
from pprint import pprint


class LaunchScript:
    def __init__(self):
        self.setup_logger()
        self.logger = logging.getLogger("launch_script")
        self.extractor = SpanExtractor()

    def setup_logger(self):
        logger = logging.getLogger("central_logger")
        logger.setLevel(logging.DEBUG)

        default_handler = logging.FileHandler("logs/default.log")
        error_handler = logging.FileHandler("logs/error.log")
        error_handler.setLevel(logging.ERROR)

        formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )
        default_handler.setFormatter(formatter)
        error_handler.setFormatter(formatter)

        logger.addHandler(default_handler)
        logger.addHandler(error_handler)

    def parse_arguments(self):
        parser = argparse.ArgumentParser(description="Process some value.")
        parser.add_argument(
            "-i",
            "--input",
            type=str,
            help="Output file where to save the result, a CSV file",
        )
        return parser.parse_args()

    def process_file(self, input_file):
        with open(input_file, "r") as file:
            reader = csv.reader(file)
            next(reader)
            for row in reader:
                span_name = row[0]
                start_time = row[1] or None
                end_time = row[2] or None
                number_of_traces = int(row[3]) or None
                service_name = row[4] or None

                name_slug = slugify(span_name)
                global_output = f"clusters/{name_slug}_cluster.json"

                self.logger.info(f"Processing span: {span_name}")
                cluster = self.extractor.traversal(
                    span_name, [start_time, end_time], number_of_traces, global_output
                )
                # with open("clusters/post-admin-service-category-add_cluster.json", "r") as file:
                #     cluster = json.load(file)

                self.process_cluster(cluster, span_name, service_name)

    def sort_by_timestamp(self, data):
        # Convert the timestamp string to a datetime object for sorting
        sorted_data = sorted(
            data,
            key=lambda x: datetime.fromisoformat(x[0]["timestamp"].replace("Z", "")),
        )
        return sorted_data

    def process_cluster(self, cluster, span_name, service_name):
        i = 1
        for key, data in cluster.items():
            pattern = data["pattern"]

            # relations = self.extractor.create_relations(pattern)
            # descendance = self.extractor.trace_hierarchical_descent(relations)
            # sorted_data = pattern[::-1]
            eql_config = get_configurations().get("eql_query", {})
            time_range = eql_config.get("time_range", "4h")
            size = eql_config.get("size", 100)
            eql_query = self.extractor.generate_eql_query(
                pattern, service_name, span_name, time_range=time_range, size=size
            )

            watcher = WatcherWorker(
                span_name=span_name + "Pattern" + str(i),
                service_name=service_name,
                eql_query=eql_query,
                eql_index_name=f"eql_watcher_{slugify(span_name)}",
            )
            watcher.config = get_configurations()
            watcher.create_update_watcher()

            self.logger.info(f"Created watcher for pattern {i} of span: {span_name}")
            i += 1

    def run(self):
        args = self.parse_arguments()
        self.process_file(args.input)


if __name__ == "__main__":
    launch_script = LaunchScript()
    launch_script.run()
