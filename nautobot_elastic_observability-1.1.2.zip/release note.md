- ## Nautobot Elastic Observability Plugin V1.1.1 - 16/07/2024

  ### 📝 **Overview**

  This release introduces significant enhancements to the Nautobot Elastic Observability Plugin, focusing on improved MIB file handling. Key changes include new features for MIB file management and essential technical updates.

  ### 🎉 **Features Update**

  - **Generating DIC File When Importing New Private MIBs File**: 
    - For new or updated private MIB files, the `mib_path` option is generated according to the current value of `snmp_input_mibs_path` present in the ini file.
    - The DIC file for private MIB is also generated and saved in a local path. The path is generated based on the file name and MIB vendor name.
  - **Check If Private MIB is in a Dataset and Set MIB Path Option in Pipeline**: 
    - When creating a dataset that includes a private MIB file, the plugin will search for it during pipeline generation and assign the MIB path value to the pipeline.
  - **Endpoint to expose dic file** : this enpoint  take as parameter a date string and return link to all dic file of mib updated or created after that date to the moment

  ### 🔧 **Technical Changes**

  - **Install Smidump**: The plugin now requires `smidump` to be installed on your machine. To install it, open your terminal and enter the following command:
  
    ```
    apt-get install smitools
    ```
  
  - **Ensure that the variable `SNMP_INPUT_MIB_PATHS` is present in the default section of the `nautobot-elastic-config.ini` file**: 
  
    - This variable represents the base path where MIB files converted to DIC will be stored. It is also in this base path where the SNMP input `mib_path` will be searched for DIC files.
  
  - Add the variable **`SMIPATH`** in default section of the `nautobot-elastic-config.ini`
  
    - This variable is the path to the directory that contains all **MIB** files that should be use by smidump to generate dic file