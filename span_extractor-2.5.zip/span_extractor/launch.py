import json
import argparse
import logging
import csv
import uuid
from datetime import datetime
from span_extractor import SpanExtractor
from watcher_script import WatcherWorker
from utils import get_configurations
from slugify import slugify
from pprint import pprint


class LaunchScript:
    def __init__(self):
        self.setup_logger()
        self.logger = logging.getLogger("launch_script")
        self.extractor = SpanExtractor()

    def setup_logger(self):
        logger = logging.getLogger("central_logger")
        logger.setLevel(logging.DEBUG)

        default_handler = logging.FileHandler("logs/default.log")
        error_handler = logging.FileHandler("logs/error.log")
        error_handler.setLevel(logging.ERROR)

        formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )
        default_handler.setFormatter(formatter)
        error_handler.setFormatter(formatter)

        logger.addHandler(default_handler)
        logger.addHandler(error_handler)

    def parse_arguments(self):
        parser = argparse.ArgumentParser(description="Process some value.")
        parser.add_argument(
            "-i",
            "--input",
            type=str,
            help="Output file where to save the result, a CSV file",
        )
        return parser.parse_args()

    def process_file(self, input_file):
        with open(input_file, "r") as file:
            reader = csv.reader(file)
            next(reader)
            for row in reader:
                span_name = row[0]
                start_time = row[1] or None
                end_time = row[2] or None
                number_of_traces = int(row[3]) or None
                service_name = row[4] or None
                self.transaction_duration = row[5] or None

                name_slug = slugify(span_name)
                global_output = f"clusters/{name_slug}_cluster.json"

                self.logger.info(f"Processing span: {span_name}")
                cluster = self.extractor.traversal(
                    span_name, [start_time, end_time], number_of_traces, global_output
                )

                self.process_cluster(cluster, span_name, service_name)

    def sort_by_timestamp(self, data):
        # Convert the timestamp string to a datetime object for sorting
        sorted_data = sorted(
            data,
            key=lambda x: datetime.fromisoformat(x[0]["timestamp"].replace("Z", "")),
        )
        return sorted_data

    def get_unique_patterns(self, patterns):
        unique_patterns = []
        for pattern in patterns:
            if pattern not in unique_patterns:
                unique_patterns.append(pattern)
        return unique_patterns

    def generate_subfields(self, patterns):
        visited_spans = {}
        child_parent_pairs = {}

        for parent, child in patterns:
            # Gérer les event.id
            for node in (parent, child):
                span_name = node["span.name"]
                if (
                    (visited := visited_spans.get(span_name))
                    and visited["processor.event"] == node["processor.event"]
                    and visited["service.name"] == node["service.name"]
                ):
                    node["event.id"] = visited["event.id"]
                else:
                    node["event.id"] = str(uuid.uuid4())
                    visited_spans[span_name] = {
                        "processor.event": node["processor.event"],
                        "event.id": node["event.id"],
                        "service.name": node["service.name"],
                    }

            # Gérer les parent.id
            child["parent.id"] = parent["event.id"]
            child_parent_pairs[child["event.id"]] = parent["event.id"]
            if parent["event.id"] in child_parent_pairs:
                parent["parent.id"] = child_parent_pairs[parent["event.id"]]

        with open("data.json", "w") as f:
            json.dump(patterns, f, indent=4)
        return patterns

    def process_cluster(self, cluster, span_name, service_name):
        eql_config = get_configurations().get("eql_query", {})
        time_range = eql_config.get("time_range", "4h")
        size = eql_config.get("size", 100)

        # Structure pour stocker les couples avec leurs patterns associés
        patterns_by_couple = {}

        print(f"Total patterns in cluster: {len(cluster)}")

        # Traitement initial des patterns
        for key, data in list(cluster.items()):
            print(f"Processing pattern: {cluster}")
            pattern = data["pattern"]

            if pattern:
                final_transaction = pattern[-1][1]["span.name"]
                interm_transaction = len(pattern) - 1
                if interm_transaction > 99:
                    continue
                couple = (final_transaction, interm_transaction)
            else:
                couple = ()

            # Stocke le pattern avec son couple correspondant
            if couple not in patterns_by_couple:
                patterns_by_couple[couple] = []
            patterns_by_couple[couple].append(pattern)

        print(f"Number of unique couples: {len(patterns_by_couple)}")

        # # Sauvegarde des couples uniques
        # with open(f"logs/{slugify(span_name)}unique_couples.json", "w") as file:
        #     json.dump(list(patterns_by_couple.keys()), file)

        reunited_patterns = []
        for couple, patterns in patterns_by_couple.items():
            for pattern in patterns:
                if not pattern in reunited_patterns:
                    reunited_patterns.extend(pattern)
        
        reunited_patterns = self.generate_subfields(reunited_patterns)
        

        # Sauvegarde des patterns uniques
        with open(f"logs/{slugify(span_name)}united_patterns.json", "w") as file:
            json.dump(reunited_patterns, file)

        pattern_counter = 1
        for couple, associated_patterns in patterns_by_couple.items():
            print(f"Processing couple: {couple}")

            eql_query = self.extractor.generate_eql_query(
                couple,
                service_name,
                span_name,
                time_range=time_range,
                size=size,
                transaction_duration=self.transaction_duration,
            )

            # Pour chaque couple, crée un watcher avec tous ses patterns associés
            for pattern in associated_patterns:
                unique_transaction = not bool(couple)

                watcher = WatcherWorker(
                    span_name=f"{span_name}Pattern{pattern_counter}",
                    service_name=service_name,
                    eql_query=eql_query,
                    eql_index_name=f"eql_watcher_{slugify(span_name)}",
                    unique_transaction=unique_transaction,
                    pattern=f"pattern{pattern_counter}",
                    data_pattern=self.extractor.generate_digraph(reunited_patterns),
                )
                watcher.config = get_configurations()
                watcher.create_update_watcher()

                self.logger.info(
                    f"Created watcher for pattern {pattern_counter} of span: {span_name}"
                )
                pattern_counter += 1

        print(f"Total watchers created: {pattern_counter - 1}")
        print("Process completed")

    def run(self):
        args = self.parse_arguments()
        self.process_file(args.input)


if __name__ == "__main__":
    launch_script = LaunchScript()
    launch_script.run()
