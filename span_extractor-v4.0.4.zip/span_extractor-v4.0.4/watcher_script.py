import logging
from slugify import slugify


class WatcherWorker:
    def __init__(
        self,
        span_name: str,
        service_name: str,
        eql_query,
        eql_index_name: str,
        **kwargs,
    ):
        self.watcher_name = f"{slugify(span_name)}_watcher"
        self.watcher_id = self.watcher_name
        self.logger = logging.getLogger("WatcherWorker")
        self.span_name = span_name
        self.service_name = service_name
        self.eql_query = eql_query
        self.eql_index_name = eql_index_name
        self.logger.info(
            f"Initialized WatcherWorker for span: {span_name}, service: {service_name}"
        )
        self.unique_transaction = kwargs.get("unique_transaction", False)
        self.pattern = kwargs.get("pattern", "")
        self.data_pattern = kwargs.get("data_pattern", [])

    def get_trigger(self):
        self.logger.info("Getting trigger configuration")
        trigger_time = self.config.get("trigger_time", "5m")
        self.logger.info(f"Trigger time: {trigger_time}")
        return {"schedule": {"interval": "{}".format(trigger_time)}}

    def get_condition(self):
        self.logger.info("Getting condition configuration")
        return {"compare": {"ctx.payload.hits.total.value": {"gt": 0}}}

    def get_actions(self):
        self.logger.info("Getting actions configuration")
        return {"index-action": {"index": {"index": self.eql_index_name}}}

    def get_input(self):
        self.logger.info("Getting input api configuration")
        try:
            http_input = self.config.get("http_input", {})
            headers = {
                # "Content-Type": "application/json",
                "Authorization": http_input.get("api_key"),
            }

            input = {
                "http": {
                    "request": {
                        "scheme": http_input["scheme"] or "https",
                        "host": http_input["host"],
                        "port": http_input["port"],
                        "method": "get",
                        "path": "traces-apm-default/_eql/search",
                        "headers": headers,
                        "body": self.eql_query,
                        "read_timeout_millis": 240000,
                    }
                }
            }
            self.logger.info("Input configuration created successfully")
            return input
        except Exception as e:
            self.logger.error(f"Failed to get input configuration: {e}")
            raise

    def get_transform(self, pattern: str, data: list, unique_transaction: bool):
        """
        Gets transform configuration for Elasticsearch painless script.

        Args:
            pattern (str): Pattern to be applied
            data (list): Graph data for parent-child relationships
            unique_transaction (bool): Flag to determine transformation type

        Returns:
            dict: Transform configuration with painless script
        """
        self.logger.info("Getting transform configuration")

        if unique_transaction:
            source = """
            def final_event_list = [];
            for (def event: ctx.payload.hits.events) {
                def span_id = event._source.span.id;
                event._source.pattern = params.pattern;
                final_event_list.add(event._source);
            }
            return ['_doc': final_event_list];
            """
        else:
            source = """
            def digraph = params.data;
            def root_node = digraph[0];
            def head_node = digraph[1];

            def final_event_list = [];
            for (def sequence: ctx.payload.hits.sequences) {
                def join_keys = sequence.join_keys;
                def sequenceId = UUID.randomUUID().toString();
                def trace_id = join_keys[0];
                
                //  earliest timestamp
                def earliest_timestamp = null;
                for (def event: sequence.events) {
                    // Parse timestamp string to ZonedDateTime for comparison
                    def currentTimestamp = ZonedDateTime.parse(event._source['@timestamp']);
                    if (earliest_timestamp == null || currentTimestamp.isBefore(ZonedDateTime.parse(earliest_timestamp))) {
                        earliest_timestamp = event._source['@timestamp'];
                    }
                }
                
                // Create synthetic root transaction event
                def synthetic_event = [:];
                synthetic_event.processor = ['event': 'transaction'];
                synthetic_event.service = ['name': head_node[5]];
                synthetic_event.transaction = [
                    'name': root_node[1],
                    'id': root_node[0],
                    'duration': ['us': 1020000]
                ];
                synthetic_event.event = ['outcome': 'failure'];
                synthetic_event.pattern = params.pattern;
                synthetic_event._id = trace_id + "_root_transaction";
                synthetic_event.event_type = 'transaction';
                synthetic_event.event_name = root_node[1];
                synthetic_event.event_durationus = 1020000;
                synthetic_event.event_id = root_node[0];
                synthetic_event['@timestamp'] = earliest_timestamp;
                
                // Add synthetic event to the list first
                final_event_list.add(synthetic_event);
                
                for (def event: sequence.events) {
                    def span_id = event._source.span.id;
                    event._source.pattern = params.pattern;
                    
                    def custom_id = trace_id + "_" + span_id;
                    event._id = custom_id;
                    def event_type = event._source.processor.event;
                    event._source.event_type = event_type;

                    def fieldname;
                    if (event_type == 'transaction') {
                        fieldname = event._source.transaction.name;
                        event._source.event_durationus = event._source.transaction.duration.us;
                        event._source.event_subtype = event._source.transaction.type;
                    } else {
                        fieldname = event._source.span.name;
                        event._source.event_durationus = event._source.span.duration.us;
                        event._source.event_subtype = event._source.span.type;
                    }
                    event._source.event_name = fieldname;
                    for (int i = 1; i < digraph.size(); i++) {
                        if (digraph[i][1] == fieldname) {
                            event._source.event_id  = digraph[i][0];
                            event._source.parent_id = digraph[i][2];
                            event._source.parent_name = digraph[i][3];
                            event._source.parent_type = digraph[i][4];
                            event._source.parent_service = digraph[i][5];
                        }
                    }
                    final_event_list.add(event._source);
                }
            }

            return ['_doc': final_event_list];
                        """

        return {
            "script": {
                "source": source,
                "lang": "painless",
                "params": {"pattern": pattern, "data": data},
            }
        }

    def get_metadata(self):
        self.logger.info("Getting metadata configuration")
        return {"type": "eql-watcher"}

    def create_update_watcher(self):
        self.logger.info(f"Creating/updating watcher: {self.watcher_name}")
        watcher_client = self.es_client.watcher

        try:
            res = watcher_client.put_watch(
                id=self.watcher_id,
                trigger=self.get_trigger(),
                condition=self.get_condition(),
                actions=self.get_actions(),
                input=self.get_input(),
                transform=self.get_transform(
                    self.pattern, self.data_pattern, self.unique_transaction
                ),
                metadata=self.get_metadata(),
            )
            self.logger.info(
                f"Watcher {self.watcher_name} created/updated successfully"
            )
            self.logger.info(res.body)
            print(res.body)
        except Exception as e:
            self.logger.error(
                f"An error occurred when creating/updating {self.watcher_name}: {e}"
            )
            raise


# if __name__ == "__main__":
#     worker = WatcherWorker("POST api/auth/signup/$", "", {})
#     worker.get_configurations()
#     pprint(worker.get_input())
#     worker.create_update_watcher()
