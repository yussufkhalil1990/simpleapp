from utils import Utils
from traces_analysis import analyse_traces
from eql_generator import EqlQueryGenerator
from watcher_script import WatcherWorker
from slugify import slugify
from data_classes import NodeCategory
from datetime import datetime
from traces_extractor import get_trace_ids
from logger_config import LoggerConfig
import asyncio
from typing import List, Dict, Any
from elasticsearch.helpers import bulk

logger = LoggerConfig.setup_logger(__name__)


async def create_root_transaction_bulk(
    es_client, root_categories: List[NodeCategory], index_name: str
):
    """
    Create documents for root transactions in bulk
    """
    current_timestamp = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.%fZ")

    # Create index if it doesn't exist
    if not es_client.indices.exists(index=index_name):
        mappings = {
            "mappings": {
                "properties": {
                    "@timestamp": {"type": "date"},
                    "event_id": {"type": "keyword"},
                    "event_name": {"type": "keyword"},
                    "event_type": {"type": "keyword"},
                    "event": {"properties": {"outcome": {"type": "keyword"}}},
                    "service": {"properties": {"name": {"type": "keyword"}}},
                }
            }
        }
        es_client.indices.create(index=index_name, body=mappings)

    # Prepare bulk documents
    bulk_data = [
        {
            "_index": index_name,
            "_id": root_cat.uuid,
            "@timestamp": current_timestamp,
            "event_id": root_cat.uuid,
            "event_name": root_cat.name,
            "event_type": root_cat.type,
            "event": {"outcome": "failure"},
            "service": {"name": root_cat.service},
        }
        for root_cat in root_categories
    ]
    # Bulk index
    return await asyncio.to_thread(bulk, es_client, bulk_data)


async def create_update_watcher_async(watcher):
    """
    Async wrapper for create_update_watcher
    """
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, watcher.create_update_watcher)


async def process_pattern(
    pattern,
    input_data: List[Dict[str, Any]],
    multi_analysis,
    root_node_category: NodeCategory,
    eql_generator: EqlQueryGenerator,
    es_client,
    config: Dict[str, Any],
    pattern_counter: int,
) -> Dict[str, Any]:
    """
    Process individual pattern asynchronously
    """
    transaction_info = next(
        (
            {"duration": row["transaction_duration"], "index_name": row["index_name"]}
            for row in input_data
            if row["root_span_name"] == pattern.root
            and row["service_name"] == pattern.service_name
        ),
        {"duration": None, "index_name": None},
    )

    root_node_category.service = pattern.service_name

    # Get head transaction for digraph
    head_transaction = next(
        (
            [
                node.uuid,
                node.name,
                root_node_category.uuid,
                root_node_category.name,
                root_node_category.type,
                root_node_category.service,
            ]
            for node in multi_analysis.unique_node_categories
            if node.name == pattern.root and node.service == pattern.service_name
        ),
        [],
    )

    if not head_transaction:
        logger.warning(
            f"Head transaction not found for {pattern.root} in {pattern.service}"
        )
        return None

    root_transaction = [root_node_category.uuid, root_node_category.name]
    digraph = [root_transaction, head_transaction]
    digraph.extend(
        [
            [
                child.uuid,
                child.name,
                parent.uuid,
                parent.name,
                parent.type,
                parent.service,
            ]
            for parent, child in multi_analysis.unique_parent_child
        ]
    )

    # Generate EQL query
    eql_query = eql_generator.generate_eql_query(
        pattern,
        time_range=config["eql_query"]["time_range"],
        size=config["eql_query"]["size"],
        transaction_duration=transaction_info["duration"],
    )

    # Create watcher instance
    watcher = WatcherWorker(
        span_name=f"{pattern.root}Pattern{pattern_counter}",
        service_name=pattern.service_name,
        eql_query=eql_query,
        eql_index_name=transaction_info["index_name"],
        unique_transaction=pattern.count == 1,
        pattern=f"{slugify(pattern.root)}_pattern{pattern_counter}",
        data_pattern=digraph,
    )
    watcher.config = config
    watcher.es_client = es_client

    return {
        "root_category": root_node_category,
        "index_name": transaction_info["index_name"],
        "watcher": watcher,
    }


async def main():
    try:
        utils = Utils()
        es_client = utils.connect_to_elasticsearch()
        args = utils.parse_arguments()
        config = utils.get_configurations()

        # Read input data
        input_data = utils.get_csv_input(args.input)
        start_time = input_data[0]["start_date"]
        end_time = input_data[0]["end_date"]
        index_pattern = config["elasticsearch"].get("index_pattern", None) 
        if not index_pattern:
            logger.error("Index pattern not found in configuration")
            raise ValueError("Index pattern not found in configuration")

        # Get trace IDs
        trace_ids = await get_trace_ids(es_client, index_pattern, input_data, start_time, end_time)
        if not trace_ids:
            logger.warning("No trace IDs found for the given criteria")
            return

        # Run analysis
        multi_analysis = await analyse_traces(
            config["elasticsearch"], index_pattern, start_time, end_time, trace_ids
        )
        if not multi_analysis:
            logger.warning("No analysis data found")
            return

        eql_generator = EqlQueryGenerator()
        root_categories = []
        watchers = []
        async_tasks = []

        for idx, pattern in enumerate(multi_analysis.unique_patterns, 1):
            frequency = multi_analysis.pattern_frequency[pattern]
            logger.info(
                f"Pattern: {pattern.root} -> {pattern.tail} "
                f"[{pattern.count} - {pattern.node_cat_count}]"
            )
            logger.info(f"Frequency: {frequency} traces")

            root_node_category = NodeCategory(
                name="Root Node",
                type="transaction",
                service="Unknown",
                event_type="root",
            )

            task = process_pattern(
                pattern,
                input_data,
                multi_analysis,
                root_node_category,
                eql_generator,
                es_client,
                config,
                idx,
            )
            async_tasks.append(task)

        # Process patterns concurrently
        results = await asyncio.gather(*async_tasks)
        results = [r for r in results if r is not None]

        if not results:
            logger.warning("No valid patterns were processed")
            return

        # Collect root categories and watchers
        root_categories = [r["root_category"] for r in results]
        watchers = [r["watcher"] for r in results]

        # Bulk create root transactions
        await create_root_transaction_bulk(
            es_client, root_categories, results[0]["index_name"]
        )

        # Create/update watchers concurrently using the async wrapper
        watcher_tasks = [create_update_watcher_async(w) for w in watchers]
        await asyncio.gather(*watcher_tasks)

    except Exception as e:
        logger.error(f"Error in main execution: {str(e)}", exc_info=True)
        raise


if __name__ == "__main__":
    asyncio.run(main())
