import argparse
import csv
import logging
import yaml
from slugify import slugify
from elasticsearch import Elasticsearch
from typing import List, Dict, Optional
from logger_config import LoggerConfig
from datetime import datetime
from datetime import datetime
from typing import List, Dict, Optional


class ValidationError(Exception):
    """Custom exception for CSV validation errors"""
    pass


class Utils:
    def __init__(self):
        # Initialize attributes to store return values and configurations
        self.es_connection = None
        self.configurations = None
        self.logger = LoggerConfig.setup_logger(__name__)
        self.transaction_duration = None
        self.index_name = None
        self.extractor = None  # You'll need to import or define this

    def connect_to_elasticsearch(self):
        """
        Connects to Elasticsearch and stores the connection as an instance attribute.

        Returns:
            Elasticsearch: Elasticsearch connection object
        """
        self.logger.info("Connecting to Elasticsearch")
        config = self.get_configurations()["elasticsearch"]

        configurations = {
            "basic_auth": (config.get("username"), config.get("password")),
            "verify_certs": config.get("verify_certs", False),
            "timeout": config.get("timeout", 30),
            "max_retries": config.get("max_retries", 3),
            "retry_on_timeout": True,
        }

        self.es_connection = Elasticsearch(
            hosts=f"{config.get('scheme')}://{config.get('host')}:{config.get('port')}/",
            **configurations,
        )
        return self.es_connection

    def get_configurations(self):
        """
        Loads configurations from a YAML file and stores them as an instance attribute.

        Returns:
            dict: Loaded configurations
        """
        self.logger.info("Loading configurations from YAML file")
        try:
            with open("config_file.yaml", "r") as file:
                self.configurations = yaml.safe_load(file)

            self.logger.info("Configurations loaded successfully")
            return self.configurations
        except Exception as e:
            self.logger.exception(f"Failed to load configurations: {e}")
            raise

    def parse_arguments(self):
        """
        Parses command-line arguments.

        Returns:
            argparse.Namespace: Parsed arguments
        """
        parser = argparse.ArgumentParser(description="Process some value.")
        parser.add_argument(
            "-i",
            "--input",
            type=str,
            help="Output file where to save the result, a CSV file",
        )
        return parser.parse_args()




    

    def get_csv_input(self, input_file: str) -> List[Dict[str, Optional[str]]]:
        """
        Read CSV file and convert rows into a list of dictionaries with robust validation.

        Args:
            input_file (str): Path to the input CSV file

        Returns:
            List[Dict[str, Optional[str]]]: List of dictionaries containing validated CSV data

        Raises:
            ValidationError: If the CSV data fails validation checks
            FileNotFoundError: If the input file is not found
            csv.Error: If there are issues reading the CSV
        """
        self.logger.info(f"Reading CSV file: {input_file}")

        required_headers = {
            "root_span_name",
            "start_date",
            "end_date",
            "number_of_traces",
            "service_name",
            "transaction_duration",
            "index_name",
        }

        try:
            csv_data = []

            with open(input_file, "r") as file:
                # Debug: Print raw file content
                raw_content = file.read()
                self.logger.debug(f"Raw file content:\n{raw_content}")
                file.seek(0)

                # Read first line to validate headers
                first_line = file.readline().strip()
                if not first_line:
                    raise ValidationError("CSV file is empty")

                self.logger.debug(f"First line: {first_line}")
                headers = set(h.strip() for h in first_line.split(","))
                self.logger.debug(f"Detected headers: {headers}")

                missing_headers = required_headers - headers
                if missing_headers:
                    raise ValidationError(f"Missing required headers: {missing_headers}")

                file.seek(0)  # Reset file pointer to start
                csv_reader = csv.DictReader(file)

                for row_num, row in enumerate(
                    csv_reader, start=2
                ):  # Start from 2 to account for header row
                    self.logger.debug(f"Processing row {row_num}: {row}")

                    # Skip empty lines
                    if not any(row.values()):
                        self.logger.warning(f"Skipping empty line at row {row_num}")
                        continue

                    # Validate and clean each field
                    try:
                        cleaned_row = {}

                        # Process required fields
                        required_fields = {
                            "root_span_name": (
                                self._validate_string_field,
                                {"required": True},
                            ),
                            "service_name": (
                                self._validate_string_field,
                                {"required": True},
                            ),
                            "start_date": (self._validate_date_field, {"required": True}),
                            "end_date": (self._validate_date_field, {"required": True}),
                        }

                        # Validate all required fields first
                        for field, (validator, kwargs) in required_fields.items():
                            value = validator(row.get(field), field, row_num, **kwargs)
                            if (
                                value is None
                            ):  # If any required field is missing/invalid, skip the row
                                raise ValidationError(
                                    f"Required field '{field}' is missing or invalid"
                                )
                            cleaned_row[field] = value

                        # Process optional fields
                        optional_fields = {
                            "number_of_traces": (self._validate_integer_field, {}),
                            "transaction_duration": (self._validate_float_field, {}),
                            "index_name": (self._validate_string_field, {}),
                        }

                        for field, (validator, kwargs) in optional_fields.items():
                            value = validator(row.get(field), field, row_num, **kwargs)
                            if value is not None:  # Only add non-None values
                                cleaned_row[field] = value

                        csv_data.append(cleaned_row)
                        self.logger.debug(f"Added cleaned row: {cleaned_row}")

                    except ValidationError as e:
                        self.logger.warning(f"Validation error in row {row_num}: {str(e)}")
                        continue  # Skip invalid rows
                    except Exception as e:
                        self.logger.warning(
                            f"Unexpected error processing row {row_num}: {str(e)}"
                        )
                        continue

            if not csv_data:
                self.logger.error("No valid data rows found in CSV file after processing")
                raise ValidationError("No valid data rows found in CSV file")

            # Store the validated data as an instance attribute
            self.csv_data = csv_data

            self.logger.info(
                f"Successfully read and validated {len(csv_data)} rows from CSV"
            )
            return csv_data

        except FileNotFoundError:
            self.logger.error(f"CSV file not found: {input_file}")
            raise
        except csv.Error as e:
            self.logger.error(f"Error reading CSV file: {e}")
            raise
        except Exception as e:
            self.logger.exception(f"Unexpected error when reading CSV: {e}")
            raise


    def _validate_string_field(
        self, value: Optional[str], field_name: str, row_num: int, required: bool = False
    ) -> Optional[str]:
        """Validate and clean string field"""
        if value is None:
            if required:
                raise ValidationError(f"Required field '{field_name}' is missing")
            return None

        cleaned = value.strip()
        if not cleaned and required:
            raise ValidationError(f"Required field '{field_name}' is empty")
        return cleaned if cleaned else None


    def _validate_integer_field(
        self, value: Optional[str], field_name: str, row_num: int
    ) -> Optional[int]:
        """Validate and convert integer field"""
        if value is None:
            return None

        cleaned = value.strip()
        if not cleaned:
            return None

        try:
            return int(cleaned)
        except ValueError:
            self.logger.warning(
                f"Invalid integer value '{value}' for field '{field_name}' in row {row_num}"
            )
            return None


    def _validate_float_field(
        self, value: Optional[str], field_name: str, row_num: int
    ) -> Optional[float]:
        """Validate and convert float field"""
        if value is None:
            return None

        cleaned = value.strip()
        if not cleaned:
            return None

        try:
            return float(cleaned)
        except ValueError:
            self.logger.warning(
                f"Invalid float value '{value}' for field '{field_name}' in row {row_num}"
            )
            return None


    def _validate_date_field(
        self, value: Optional[str], field_name: str, row_num: int, required: bool = False
    ) -> Optional[str]:
        """Validate date field format"""
        if value is None:
            if required:
                raise ValidationError(f"Required field '{field_name}' is missing")
            return None

        cleaned = value.strip()
        if not cleaned:
            if required:
                raise ValidationError(f"Required field '{field_name}' is empty")
            return None

        try:
            # First try ISO format (with time)
            try:
                datetime.fromisoformat(cleaned.replace("Z", "+00:00"))
                return cleaned
            except ValueError:
                # If ISO format fails, try simple date format
                datetime.strptime(cleaned, "%Y-%m-%d")
                return cleaned
        except ValueError:
            error_msg = f"Invalid date format '{value}' for field '{field_name}' in row {row_num}. Expected ISO format or YYYY-MM-DD"
            if required:
                raise ValidationError(error_msg)
            self.logger.warning(error_msg)
            return None


# Example usage
if __name__ == "__main__":
    utils = Utils()

    # Example of using the methods
    try:
        # Load configurations
        configs = utils.get_configurations()

        # Connect to Elasticsearch
        es_client = utils.connect_to_elasticsearch()

        # Parse arguments
        args = utils.parse_arguments()

        # Process input file if provided
        if args.input:
            utils.process_file(args.input)

    except Exception as e:
        utils.logger.exception(f"An error occurred: {e}")
