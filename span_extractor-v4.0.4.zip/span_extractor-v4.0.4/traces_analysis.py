from typing import List, Dict, Any, Tuple, Set, Optional
from elasticsearch import AsyncElasticsearch, Elasticsearch
import logging
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor
import asyncio
from functools import partial
import traceback
from logger_config import LoggerConfig
from data_classes import (
    TracePattern,
    TraceNode,
    NodeCategory,
    TraceAnalysis,
    MultiTraceAnalysis,
)

class TraceAnalyzer:
    def __init__(self, es_client: Elasticsearch):
        self.es_client = es_client
        self.logger =LoggerConfig.setup_logger(__name__)

    def _create_nodes(
        self, events: Dict[str, Any]
    ) -> Tuple[List[TraceNode], List[NodeCategory]]:
        """
        Converts raw events into TraceNode objects.
        """
        nodes = []
        node_categories = []

        if not events or "columns" not in events or "rows" not in events:
            self.logger.error(f"Invalid events structure: {events}")
            return nodes, node_categories

        columns = events["columns"]

        for row in events["rows"]:
            try:
                event = dict(zip(columns, row))

                node_id = event.get("span.id") or event.get("transaction.id")
                if not node_id:
                    continue

                name = event.get("span.name") or event.get("transaction.name")
                type_ = event.get("span.type") or event.get("transaction.type")

                timestamp = None
                if "@timestamp" in event:
                    try:
                        timestamp = datetime.fromisoformat(
                            event["@timestamp"].replace("Z", "+00:00")
                        )
                    except (ValueError, AttributeError):
                        self.logger.warning(
                            f"Could not parse timestamp: {event.get('@timestamp')}"
                        )

                node = TraceNode(
                    node_id=node_id,
                    name=name or "Unknown",
                    type=type_ or "Unknown",
                    service=event.get("service.name", "Unknown"),
                    event_type=event.get("processor.event", "Unknown"),
                    parent_id=event.get("parent.id"),
                    timestamp=timestamp,
                )

                node_category = NodeCategory(
                    name=name or "Unknown",
                    type=type_ or "Unknown",
                    service=event.get("service.name", "Unknown"),
                    event_type=event.get("processor.event", "Unknown"),
                )

                nodes.append(node)
                node_categories.append(node_category)

            except Exception as e:
                self.logger.error(f"Error processing row {row}: {e}")
                self.logger.exception(traceback.format_exc())
                continue

        return nodes, list(set(node_categories))

    def _create_parent_child_pairs(
        self, nodes: List[TraceNode]
    ) -> List[Tuple[str, str]]:
        pairs = []
        for node in nodes:
            if node.parent_id:
                pairs.append((node.parent_id, node.node_id))
        return pairs

    def _find_root_node(self, nodes: List[TraceNode]) -> TraceNode:
        for node in nodes:
            if not node.parent_id:
                return node

        if nodes:
            self.logger.warning("No explicit root node found, using first node")
            return nodes[0]

        raise ValueError("No nodes found in trace")

    def _find_tail_nodes(
        self, nodes: List[TraceNode], pairs: List[Tuple[str, str]]
    ) -> List[TraceNode]:
        parent_ids = set(pair[0] for pair in pairs)
        tail_nodes = []
        for node in nodes:
            if node.node_id not in parent_ids:
                tail_nodes.append(node)
        return tail_nodes

    def _find_latest_tail_node(
        self, tail_nodes: List[TraceNode]
    ) -> Optional[TraceNode]:
        if not tail_nodes:
            return None

        nodes_with_timestamps = [
            node for node in tail_nodes if node.timestamp is not None
        ]

        if not nodes_with_timestamps:
            self.logger.warning("No tail nodes have timestamps")
            return tail_nodes[0]

        return max(nodes_with_timestamps, key=lambda x: x.timestamp)

class ChunkedTraceAnalyzer:
    def __init__(self, es_client: AsyncElasticsearch, index_pattern ,chunk_size: int = 1000):
        self.es_client = es_client
        self.index_pattern = index_pattern
        self.chunk_size = chunk_size
        self.logger = LoggerConfig.setup_logger(__name__)

    async def _bulk_query_trace_events(
        self, trace_ids: List[str], start_time: datetime, end_time: datetime
    ) -> Dict[str, List[Dict]]:
        """
        Query Elasticsearch for multiple trace IDs in a single request
        """
        query = {
            "query": {
                "bool": {
                    "must": [
                        {"terms": {"trace.id": trace_ids}},
                        {
                            "range": {
                                "@timestamp": {
                                    "gte": start_time,
                                    "lte": end_time,
                                }
                            }
                        },
                    ]
                }
            },
            "_source": [
                "trace.id",
                "span.id",
                "span.name",
                "span.type",
                "transaction.id",
                "transaction.name",
                "transaction.type",
                "processor.event",
                "parent.id",
                "service.name",
                "@timestamp",
            ],
            "size": 10000,  # Adjust based on your needs
        }

        try:
            response = await self.es_client.search(index=self.index_pattern, body=query)
            hits = response.get("hits", {}).get("hits", [])

            # Group events by trace ID
            events_by_trace = {}
            columns = query["_source"]

            for hit in hits:
                source = hit["_source"]
                trace_id = source.get("trace")["id"]

                if trace_id not in events_by_trace:
                    events_by_trace[trace_id] = {"rows": [], "columns": columns}

                row = []
                for column in columns:
                    value = source
                    for key in column.split("."):
                        value = value.get(key, {}) if isinstance(value, dict) else None
                    row.append(value if value != {} else None)

                events_by_trace[trace_id]["rows"].append(row)

            return events_by_trace

        except Exception as e:
            self.logger.error(f"Failed to query Elasticsearch: {e}")
            self.logger.exception(traceback.format_exc())
            raise


class OptimizedMultiTraceAnalyzer:
    def __init__(
        self,
        es_client: AsyncElasticsearch,
        index_pattern,
        max_workers: int = 5,
        chunk_size: int = 1000,
    ):
        self.chunked_analyzer = ChunkedTraceAnalyzer(es_client, index_pattern, chunk_size)
        self.trace_analyzer = TraceAnalyzer(es_client)
        self.logger = LoggerConfig.setup_logger(__name__)
        self.max_workers = max_workers
        self.chunk_size = chunk_size

    async def analyze_traces(
        self,
        trace_ids: List[str],
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
    ) -> MultiTraceAnalysis:
        if not trace_ids:
            raise ValueError("No trace IDs provided")

        self.logger.info(f"Starting chunked analysis of {len(trace_ids)} traces")
        
        analyses = []
        failed_traces = []
        processed_chunks = 0
        total_chunks = len(range(0, len(trace_ids), self.chunk_size))

        # Process in chunks with error handling
        for i in range(0, len(trace_ids), self.chunk_size):
            chunk = trace_ids[i:i + self.chunk_size]
            processed_chunks += 1
            
            try:
                events_by_trace = await self.chunked_analyzer._bulk_query_trace_events(
                    chunk, start_time, end_time
                )
                
                if not events_by_trace:
                    failed_traces.extend([(tid, "No events found") for tid in chunk])
                    continue

                with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                    loop = asyncio.get_event_loop()
                    futures = []

                    for trace_id in chunk:
                        if trace_id not in events_by_trace:
                            failed_traces.append((trace_id, "No events found for trace"))
                            continue
                            
                        future = loop.run_in_executor(
                            executor,
                            partial(self._process_single_trace, trace_id, events_by_trace[trace_id], 
                                   start_time, end_time)
                        )
                        futures.append((trace_id, future))

                    for trace_id, future in futures:
                        try:
                            analysis = await future
                            if analysis:  # Only append valid analyses
                                analyses.append(analysis)
                        except Exception as e:
                            failed_traces.append((trace_id, str(e)))
                            self.logger.error(f"Failed to analyze trace {trace_id}: {e}")
                            self.logger.exception(traceback.format_exc())

            except Exception as e:
                self.logger.error(f"Failed to process chunk {processed_chunks}/{total_chunks}: {e}")
                self.logger.exception(traceback.format_exc())
                failed_traces.extend([(tid, str(e)) for tid in chunk])

            # Log progress
            if processed_chunks % 10 == 0:
                self.logger.info(f"Processed {processed_chunks}/{total_chunks} chunks. "
                               f"Success: {len(analyses)}, Failed: {len(failed_traces)}")

        if analyses:  # Create analysis if we have any successful results
            try:
                return self._create_multi_trace_analysis(analyses, start_time, end_time)
            except Exception as e:
                self.logger.error(f"Failed to create multi-trace analysis: {e}")
                self.logger.exception(traceback.format_exc())
                if len(analyses) > len(failed_traces):  # If we have more successes than failures
                    # Try again with just the first successful chunk
                    return self._create_multi_trace_analysis(analyses[:self.chunk_size], 
                                                           start_time, end_time)
        raise ValueError(f"No successful analyses out of {len(trace_ids)} traces. "
                        f"Failed traces: {len(failed_traces)}")

    def _process_single_trace(self, trace_id: str, events: Dict[str, Any], 
                            start_time: datetime, end_time: datetime) -> Optional[TraceAnalysis]:
        try:
            nodes, node_categories = self.trace_analyzer._create_nodes(events)
            if not nodes:
                return None

            pairs = self.trace_analyzer._create_parent_child_pairs(nodes)
            try:
                root_node = self.trace_analyzer._find_root_node(nodes)
            except ValueError:
                self.logger.warning(f"No root node found for trace {trace_id}")
                return None

            tail_nodes = self.trace_analyzer._find_tail_nodes(nodes, pairs)
            latest_tail_node = self.trace_analyzer._find_latest_tail_node(tail_nodes)

            pattern = TracePattern(
                root=root_node.name,
                tail=latest_tail_node.name if latest_tail_node else "Unknown",
                count=len(nodes),
                node_cat_count=len(node_categories),
                service_name=root_node.service,
            )

            return TraceAnalysis(
                trace_id=trace_id,
                nodes=nodes,
                node_categories=node_categories,
                parent_child_pairs=pairs,
                root_node=root_node,
                tail_nodes=tail_nodes,
                latest_tail_node=latest_tail_node,
                node_count=len(nodes),
                time_range=(start_time, end_time),
                pattern=pattern,
            )

        except Exception as e:
            self.logger.error(f"Error processing trace {trace_id}: {e}")
            self.logger.exception(traceback.format_exc())
            return None

    def _create_multi_trace_analysis(
        self,
        analyses: List[TraceAnalysis],
        start_time: Optional[datetime],
        end_time: Optional[datetime],
    ) -> MultiTraceAnalysis:
        """Create consolidated analysis from individual trace analyses"""
        if not analyses:
            raise ValueError("No successful trace analyses to consolidate")

        # Find global time range
        if not start_time:
            start_time = min(analysis.time_range[0] for analysis in analyses)
        if not end_time:
            end_time = max(analysis.time_range[1] for analysis in analyses)

        # Consolidate and create unique node categories
        all_node_categories = []
        for analysis in analyses:
            all_node_categories.extend(analysis.node_categories)

        # Create unique node categories using a set
        unique_node_categories = list(
            {
                NodeCategory(
                    name=node.name,
                    type=node.type,
                    service=node.service,
                    event_type=node.event_type,
                )
                for node in all_node_categories
            }
        )

        # Get unique patterns and their frequencies
        patterns = [analysis.pattern for analysis in analyses]
        unique_patterns = set(patterns)
        pattern_frequency = {
            pattern: patterns.count(pattern) for pattern in unique_patterns
        }

        # Collect unique parent-child pairs across all traces
        unique_parent_child = set()
        for analysis in analyses:
            for parent_id, child_id in analysis.parent_child_pairs:
                parent = next(n for n in analysis.nodes if n.node_id == parent_id)
                child = next(n for n in analysis.nodes if n.node_id == child_id)

                # Find or create parent and child NodeCategory instances
                parent_node_cat = next(
                    (
                        cat
                        for cat in unique_node_categories
                        if cat.name == parent.name
                        and cat.type == parent.type
                        and cat.service == parent.service
                        and cat.event_type == parent.event_type
                    ),
                    NodeCategory(
                        name=parent.name,
                        type=parent.type,
                        service=parent.service,
                        event_type=parent.event_type,
                    ),
                )

                child_node_cat = next(
                    (
                        cat
                        for cat in unique_node_categories
                        if cat.name == child.name
                        and cat.type == child.type
                        and cat.service == child.service
                        and cat.event_type == child.event_type
                    ),
                    NodeCategory(
                        name=child.name,
                        type=child.type,
                        service=child.service,
                        event_type=child.event_type,
                    ),
                )

                unique_parent_child.add((parent_node_cat, child_node_cat))

        return MultiTraceAnalysis(
            trace_analyses=analyses,
            total_traces=len(analyses),
            time_range=(start_time, end_time),
            unique_patterns=unique_patterns,
            pattern_frequency=pattern_frequency,
            unique_parent_child=unique_parent_child,
            unique_node_categories=unique_node_categories,
        )


async def analyse_traces(config, index_pattern, start_time, end_time, trace_ids ):
   
    # Initialize Async Elasticsearch client
    configurations = {
        "basic_auth": (config.get("username"), config.get("password")),
    }
    es_client = AsyncElasticsearch(
        hosts=f"{config.get('scheme')}://{config.get('host')}:{config.get('port')}/",
        **configurations,
        verify_certs=False,
    )

    # Initialize optimized analyzer
    analyzer = OptimizedMultiTraceAnalyzer(es_client,index_pattern , max_workers=5, chunk_size=1000)

    try:
        # Optional: specify time range
        if not end_time and start_time:
            end_time = datetime.utcnow()
            start_time = end_time - timedelta(days=90)

        # Run analysis
        multi_analysis = await analyzer.analyze_traces(
            trace_ids=trace_ids, start_time=start_time, end_time=end_time
        )
        return multi_analysis

    except Exception as e:
        logging.error(f"Analysis failed: {e}")
        logging.exception(traceback.format_exc())
    finally:
        await es_client.close()


if __name__ == "__main__":
    asyncio.run(analyse_traces())