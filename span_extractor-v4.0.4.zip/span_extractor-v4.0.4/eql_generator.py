import json
import logging
from typing import NamedTuple, Optional, Dict, Any
from data_classes import TracePattern


class EqlQueryGenerator:
    """
    A class responsible for generating Elastic Query Language (EQL) queries
    for trace and transaction analysis.
    """

    def __init__(self):
        # Use the provided logger
        self.logger = logging.getLogger("EqlQueyGenerator")

    def generate_eql_query(
        self,
        pattern: TracePattern,
        time_range: str = "15min",
        size: int = 500,
        transaction_duration: int = 1000000,
    ) -> str:
        """
        Generate an Elastic Query Language (EQL) query based on the given trace pattern.

        Args:
            pattern (TracePattern): The trace pattern to generate a query for
            node_category_count (int): Number of node categories in the trace
            time_range (str, optional): Time range for the query. Defaults to "15min"
            size (int, optional): Maximum number of results. Defaults to 500
            transaction_duration (int, optional): Minimum transaction duration in microseconds.
                Defaults to 1,000,000 (1 second)

        Returns:
            str: A JSON-formatted EQL query
        """
        self.logger.info(
            f"Generating EQL query for service: {pattern.service_name}, "
            f"transaction: {pattern.root}"
        )

        node_category_count = pattern.node_cat_count

        try:
            # Construct the first sequence of the query
            first_sequence = (
                f'any where service.name == "{pattern.service_name}" '
                f'and transaction.name == "{pattern.root}" '
                f"and (transaction.duration.us > {transaction_duration} "
                'or event.outcome == "failure")'
            )

            # Handle query generation based on pattern count
            if pattern.count:
                query = self._build_sequence_query(
                    first_sequence, pattern.tail, node_category_count
                )
            else:
                query = first_sequence

            # Construct the full query body
            query_body = self._construct_query_body(query, time_range, size)

            # Convert to JSON and log
            eql_query = json.dumps(query_body)
            self.logger.info(f"EQL query generated successfully")
            return eql_query

        except Exception as e:
            self.logger.error(f"Error generating EQL query: {str(e)}")
            raise

    def _build_sequence_query(
        self, first_sequence: str, tail: str, node_category_count: int
    ) -> str:
        """
        Build the sequence part of the EQL query.

        Args:
            first_sequence (str): The initial sequence condition
            tail (str): The tail node name
            node_category_count (int): Number of node categories

        Returns:
            str: Constructed sequence query
        """
        event_number = node_category_count - 2

        # Handle different event number scenarios
        if event_number == 0:
            sequence = [f'any where span.name == "{tail}"']
            sequence_query = " ] [ ".join(sequence)
            return f"sequence by trace.id [ {first_sequence} ] [ {sequence_query} ]"

        # Handle multiple intermediate events
        sequence = [f'any where span.name == "{tail}"']

        if event_number > 1:
            intermediate_sequence = f"[ any where true ] with runs={event_number}"
        else:
            intermediate_sequence = "[ any where true ]"

        sequence_query = " ] [ ".join(sequence)
        return (
            f"sequence by trace.id [ {first_sequence} ] "
            f"{intermediate_sequence} [ {sequence_query} ]"
        )

    def _construct_query_body(
        self, query: str, time_range: str, size: int
    ) -> Dict[str, Any]:
        """
        Construct the full query body with fields and filters.

        Args:
            query (str): The generated EQL query
            time_range (str): Time range for the query
            size (int): Maximum number of results

        Returns:
            Dict[str, Any]: Complete query body dictionary
        """
        return {
            "query": query,
            "fields": [
                "transaction.name",
                "span.name",
                "transaction.duration.us",
                "span.duration.us",
                "processor.event",
                "event.outcome",
                "parent.id",
                "trace.id",
            ],
            "filter": {
                "range": {"@timestamp": {"gte": f"now-{time_range}", "lte": "now"}}
            },
            "size": size,
        }

if __name__ == "__main__":

    logger = logging.getLogger('eql')

    # Create EQL generator with your main logger
    eql_generator = EqlQueryGenerator(logger=logger)

    # Generate EQL query
    trace_pattern = TracePattern(
        root='root_transaction', 
        tail='tail_span', 
        count=3, 
        service_name='your_service'
    )

    eql_query = eql_generator.generate_eql_query(
        pattern=trace_pattern, 
        node_category_count=3
    )

    print(eql_query)
