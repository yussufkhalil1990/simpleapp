### Span Extractor v2.0.0  -  Readme  -  27/08/2024

## Intro

This script processes a CSV file containing span information, extracts patterns, and creates watchers in Elasticsearch.



## Prerequisites

- Python 3.x
- Required Python packages (listed in [`requirements.txt`](vscode-file://vscode-app/usr/share/code/resources/app/out/vs/code/electron-sandbox/workbench/workbench.html))

## Installation

### 1. Create a Virtual Environment (Recommended):

- **Linux/macOS:**

  ```bash
  python3 -m venv venv  # Replace "venv" with your desired environment name
  source venv/bin/activate  # Activate the virtual environment
  ```

- **Windows:**

  ```bash
  python -m venv venv  # Replace "venv" with your desired environment name
  venv\Scripts\activate  # Activate the virtual environment
  ```

### 2. Install the Wheel File and his Dependencies:

**Dependencies installation in Air-Gapped Enviromment**

Once the virtual environment is active, the following Process show you how to install all dependencies needed by the script

```
tar -zxf span-extractor-dependecies.tar.gz
```

```
pip3 install -r wheels/requirements.txt --no-index --find-links wheels
```

**Internet Environment**

 Install the wheel file:

```bash
pip install span_extractor-1.0.18-py3-none-any.whl
```



## Configuration

Ensure you have the following configuration files in place:

- [`config_file.yaml`](vscode-file://vscode-app/usr/share/code/resources/app/out/vs/code/electron-sandbox/workbench/workbench.html): Contains configurations for the [`WatcherWorker`](vscode-file://vscode-app/usr/share/code/resources/app/out/vs/code/electron-sandbox/workbench/workbench.html).
- [`logs/`](vscode-file://vscode-app/usr/share/code/resources/app/out/vs/code/electron-sandbox/workbench/workbench.html): Directory to store log files ([`default.log`](vscode-file://vscode-app/usr/share/code/resources/app/out/vs/code/electron-sandbox/workbench/workbench.html) and [`error.log`](vscode-file://vscode-app/usr/share/code/resources/app/out/vs/code/electron-sandbox/workbench/workbench.html)).

## Usage

1. Prepare the input CSV file with the following columns:

   - [`span_name`](vscode-file://vscode-app/usr/share/code/resources/app/out/vs/code/electron-sandbox/workbench/workbench.html): Name of the span.
   - [`start_time`](vscode-file://vscode-app/usr/share/code/resources/app/out/vs/code/electron-sandbox/workbench/workbench.html): Start time for the span extraction.
   - [`end_time`](vscode-file://vscode-app/usr/share/code/resources/app/out/vs/code/electron-sandbox/workbench/workbench.html): End time for the span extraction.
   - [`number_of_traces`](vscode-file://vscode-app/usr/share/code/resources/app/out/vs/code/electron-sandbox/workbench/workbench.html): Number of traces to extract.
   - [`service_name`](vscode-file://vscode-app/usr/share/code/resources/app/out/vs/code/electron-sandbox/workbench/workbench.html): Name of the service.

2. Run the script:

   ```
   python launch.py -i <input_csv_file>
   ```

3. Example

```
python launch.py -i spans.csv
```



## Logging

Logs are stored in the [`logs/`](vscode-file://vscode-app/usr/share/code/resources/app/out/vs/code/electron-sandbox/workbench/workbench.html) directory:

- [`default.log`](vscode-file://vscode-app/usr/share/code/resources/app/out/vs/code/electron-sandbox/workbench/workbench.html): General logs.
- [`error.log`](vscode-file://vscode-app/usr/share/code/resources/app/out/vs/code/electron-sandbox/workbench/workbench.html): Error logs.

## Explanation

The script performs the following steps:

1. **Setup Logger**: Initializes the logger to capture logs in [`default.log`](vscode-file://vscode-app/usr/share/code/resources/app/out/vs/code/electron-sandbox/workbench/workbench.html) and [`error.log`](vscode-file://vscode-app/usr/share/code/resources/app/out/vs/code/electron-sandbox/workbench/workbench.html).
2. **Parse Arguments**: Parses the input CSV file path from the command line arguments.
3. **Process File**: Reads the CSV file and processes each row to extract spans and create watchers.
4. **Process Cluster**: For each extracted span pattern, generates an EQL query and creates a watcher in Elasticsearch.

## Contact

For any issues or questions, please contact [[yannik.kadjiexample.com](vscode-file://vscode-app/usr/share/code/resources/app/out/vs/code/electron-sandbox/workbench/workbench.html)].
