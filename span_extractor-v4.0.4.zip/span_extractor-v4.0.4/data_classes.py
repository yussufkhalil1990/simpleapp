from typing import List, Dict, Tuple, Set, Optional, NamedTuple
from dataclasses import dataclass, field
import uuid
from datetime import datetime


class TracePattern(NamedTuple):
    root: str  # Root node name
    tail: str  # Latest tail node name
    count: int  # Total node count
    service_name: str  # Service name
    node_cat_count: int


@dataclass
class TraceNode:
    node_id: str
    name: str
    type: str
    service: str
    event_type: str
    parent_id: str = None
    timestamp: Optional[datetime] = None


@dataclass
class NodeCategory:
    name: str
    type: str
    service: str
    event_type: str
    uuid: str = field(default_factory=lambda: str(uuid.uuid4()))

    def __hash__(self):
        """Custom hash method to make NodeCategory hashable based on its attributes"""
        return hash((self.name, self.type, self.service, self.event_type))

    def __eq__(self, other):
        """Custom equality method to compare NodeCategory instances"""
        if not isinstance(other, NodeCategory):
            return False
        return (
            self.name == other.name
            and self.type == other.type
            and self.service == other.service
            and self.event_type == other.event_type
        )

    def __lt__(self, other):
        """Custom less than method to enable sorting"""
        if not isinstance(other, NodeCategory):
            return NotImplemented
    
    def __repr__(self):
        return [self.uuid, self.name, self.type, self.service, self.event_type]


@dataclass
class TraceAnalysis:
    trace_id: str
    nodes: List[TraceNode]
    node_categories: List[NodeCategory]
    parent_child_pairs: List[Tuple[str, str]]
    root_node: TraceNode
    tail_nodes: List[TraceNode]
    latest_tail_node: Optional[TraceNode]
    node_count: int
    time_range: Tuple[datetime, datetime]
    pattern: TracePattern


@dataclass
class MultiTraceAnalysis:
    """Container for multiple trace analyses with summary information"""

    trace_analyses: List[TraceAnalysis]
    total_traces: int
    time_range: Tuple[datetime, datetime]
    unique_patterns: Set[TracePattern]
    pattern_frequency: Dict[TracePattern, int]
    unique_parent_child: Set[Tuple[NodeCategory, NodeCategory]]
    unique_node_categories: List[NodeCategory]

    def get_analysis_by_trace_id(self, trace_id: str) -> Optional[TraceAnalysis]:
        """Retrieve specific trace analysis by trace ID"""
        for analysis in self.trace_analyses:
            if analysis.trace_id == trace_id:
                return analysis
        return None
