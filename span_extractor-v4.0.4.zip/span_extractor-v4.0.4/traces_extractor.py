import asyncio
from typing import List, Dict, Optional, Set
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
import traceback
from datetime import datetime, timedelta
from utils import Utils

from logger_config import LoggerConfig

logger = LoggerConfig.setup_logger(__name__)

@dataclass
class SearchCriteria:
    """Data class to hold search parameters"""

    transaction_service_pairs: List[tuple[str, str]]
    start_time: str
    end_time: str

    def __post_init__(self):
        """Validate input data after initialization"""
        if not self.transaction_service_pairs:
            raise ValueError("transaction_service_pairs cannot be empty")

        # Filter out invalid pairs
        valid_pairs = []
        for trans_name, service_name in self.transaction_service_pairs:
            # Clean up whitespace and check if strings are not empty
            trans_name = trans_name.strip() if trans_name else None
            service_name = service_name.strip() if service_name else None

            if trans_name and service_name:
                valid_pairs.append((trans_name, service_name))

        if not valid_pairs:
            raise ValueError("No valid transaction-service pairs found after filtering")

        self.transaction_service_pairs = valid_pairs

class ElasticSearchConfig:
    """Configuration class for Elasticsearch connection"""

    def __init__(
        self,
        hosts: List[str],
        api_key: Optional[str] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
        verify_certs: bool = True,
    ):
        self.hosts = hosts
        self.api_key = api_key
        self.username = username
        self.password = password
        self.verify_certs = verify_certs


class APMTraceRetriever:
    """Main class to handle trace ID retrieval from Elastic APM"""

    def __init__(self, es_client, index_pattern, max_workers: int = 10, chunk_size: int = 5000):
        self.client = es_client
        self.index_pattern = index_pattern
        self.chunk_size = chunk_size
        self.max_workers = max_workers

    def build_single_pair_query(
        self,
        transaction_name: str,
        service_name: str,
        start_time: str,
        end_time: str,
    ) -> Dict:
        """Build query for a single transaction-service pair"""
        return {
            "query": {
                "bool": {
                    "must": [
                        {"term": {"transaction.name": transaction_name}},
                        {"term": {"service.name": service_name}},
                        {
                            "range": {
                                "@timestamp": {
                                    "gte": start_time,
                                    "lte": end_time,
                                }
                            }
                        },
                    ]
                }
            },
            "_source": ["trace.id"],
            "size": self.chunk_size,
        }

    def _get_trace_ids_for_pair_sync(
        self,
        transaction_name: str,
        service_name: str,
        start_time: str,
        end_time: str,
    ) -> Set[str]:
        """Synchronous method to retrieve trace IDs for a single transaction-service pair"""
        if not self.client:
            raise RuntimeError("Not connected to Elasticsearch. Call connect() first.")

        query = self.build_single_pair_query(
            transaction_name, service_name, start_time, end_time
        )
        trace_ids = set()
        scroll_id = None

        try:
            # Initial search with scroll
            response = self.client.search(
                index=self.index_pattern, body=query, scroll="5m"
            )
            scroll_id = response["_scroll_id"]

            # Process results and scroll until no more hits
            while True:
                hits = response["hits"]["hits"]
                if not hits:
                    break

                # Extract trace IDs from current batch
                for hit in hits:
                    trace_ids.add(hit["_source"]["trace"]["id"])

                # Get next batch using scroll
                response = self.client.scroll(scroll_id=scroll_id, scroll="5m")

            logger.info(
                f"Retrieved {len(trace_ids)} trace IDs for "
                f"transaction '{transaction_name}' in service '{service_name}'"
            )
            return trace_ids

        except Exception as e:
            logger.error(
                f"Error retrieving trace IDs for transaction '{transaction_name}' "
                f"in service '{service_name}': {str(e)}"
            )
            logger.exception(traceback.format_exc())
        finally:
            # Clean up scroll context
            if scroll_id:
                try:
                    self.client.clear_scroll(scroll_id=scroll_id)
                except Exception:
                    pass

    async def get_trace_ids_for_pair(
        self,
        transaction_name: str,
        service_name: str,
        start_time: str,
        end_time: str,
        executor: ThreadPoolExecutor,
    ) -> Set[str]:
        """Asynchronously retrieve trace IDs for a single transaction-service pair"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            executor,
            self._get_trace_ids_for_pair_sync,
            transaction_name,
            service_name,
            start_time,
            end_time,
        )

    async def get_trace_ids(self, criteria: SearchCriteria) -> List[str]:
        """Retrieve trace IDs for all transaction-service pairs concurrently"""
        if not self.client:
            raise RuntimeError("Not connected to Elasticsearch. Call connect() first.")

        try:
            num_workers = min(len(criteria.transaction_service_pairs), self.max_workers)

            # Create and manage the executor within this method
            executor = ThreadPoolExecutor(max_workers=num_workers)
            try:
                # Create tasks for each transaction-service pair
                tasks = []
                for trans_name, serv_name in criteria.transaction_service_pairs:
                    task = self.get_trace_ids_for_pair(
                        trans_name,
                        serv_name,
                        criteria.start_time,
                        criteria.end_time,
                        executor,
                    )
                    tasks.append(task)

                # Execute all tasks concurrently
                results = await asyncio.gather(*tasks, return_exceptions=True)
            finally:
                # Ensure executor is shutdown properly
                executor.shutdown(wait=True)

            # Process results and handle any exceptions
            all_trace_ids = set()
            errors = []

            for idx, result in enumerate(results):
                if isinstance(result, Exception):
                    trans_name, serv_name = criteria.transaction_service_pairs[idx]
                    errors.append(
                        f"Error processing {trans_name}@{serv_name}: {str(result)}"
                    )
                else:
                    all_trace_ids.update(result)

            # Log any errors that occurred
            if errors:
                logger.error("Errors occurred during trace ID retrieval:")
                for error in errors:
                    logger.error(error)

            logger.info(f"Retrieved {len(all_trace_ids)} unique trace IDs in total")
            return list(all_trace_ids)

        except Exception as e:
            logger.error(f"Unexpected error during trace ID retrieval: {str(e)}")
            logger.exception(traceback.format_exc())
            raise


async def get_trace_ids(es_client, index_pattern,  input_data,  start_date, end_date):
    try:
        if not input_data:
            raise ValueError("No data found in input CSV file")

        # Clean and validate the input data
        transaction_service_pairs = []
        for row in input_data:
            trans_name = row.get("root_span_name", "").strip()
            service_name = row.get("service_name", "").strip()

            if trans_name and service_name:
                transaction_service_pairs.append((trans_name, service_name))

        if not transaction_service_pairs:
            raise ValueError("No valid transaction-service pairs found in input file")

        # Optional: specify time range
        if not end_date and start_date:
            end_date = datetime.utcnow()
            start_date = end_date - timedelta(days=90)

        retriever = APMTraceRetriever(es_client, index_pattern)
        criteria = SearchCriteria(
            transaction_service_pairs=transaction_service_pairs,
            start_time=start_date,
            end_time=end_date,
        )

        trace_ids = await retriever.get_trace_ids(criteria)
        if not trace_ids:
            logger.warning("No trace IDs found for the given criteria")
            return []

        logger.info(f"Retrieved {len(trace_ids)} unique trace IDs")
        return trace_ids

    except Exception as e:
        logger.error(f"Error: {str(e)}")
        logger.exception(traceback.format_exc())
        raise

# if __name__ == "__main__":
#     asyncio.run(get_trace_ids())
