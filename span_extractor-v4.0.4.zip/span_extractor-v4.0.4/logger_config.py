import logging
import sys
import os


class LoggerConfig:
    @staticmethod
    def setup_logger(logger_name="central"):
        """
        Configure un logger statique utilisable dans toute l'application.
        Les anciens logs sont supprimés à chaque nouvelle exécution.

        Args:
            logger_name (str): Nom du logger, par défaut "central"

        Returns:
            logging.Logger: Instance du logger configuré
        """
        # Créer le logger
        logger = logging.getLogger(logger_name)
        logger.setLevel(logging.DEBUG)

        # Assurer que le dossier logs existe
        os.makedirs("logs", exist_ok=True)

        # Noms des fichiers de log
        default_log_path = f"logs/{logger_name}_default.log"
        error_log_path = f"logs/{logger_name}_error.log"

        # Supprimer les anciens fichiers de log s'ils existent
        if os.path.exists(default_log_path):
            os.remove(default_log_path)
        if os.path.exists(error_log_path):
            os.remove(error_log_path)

        # Handlers avec mode 'w' pour écraser le contenu
        default_handler = logging.FileHandler(default_log_path, mode="w")
        default_handler.setLevel(logging.INFO)

        error_handler = logging.FileHandler(error_log_path, mode="w")
        error_handler.setLevel(logging.ERROR)

        # Console handler pour les erreurs critiques
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.ERROR)

        # Formatter détaillé
        formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - "
            "%(filename)s:%(lineno)d - %(funcName)s() - %(message)s"
        )
        default_handler.setFormatter(formatter)
        error_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)

        # Effacer les anciens handlers
        logger.handlers.clear()

        # Ajouter les nouveaux handlers
        logger.addHandler(default_handler)
        logger.addHandler(error_handler)
        logger.addHandler(console_handler)

        return logger
